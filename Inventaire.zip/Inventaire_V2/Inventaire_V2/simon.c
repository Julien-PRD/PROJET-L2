#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "fonction_basiques.h"

// http://sdz.tdct.org/sdz/faire-des-rotations-avec-sdl-gfx.html
// apprendre rotation



int est_a_cote(image_t image, player_t player){
	if(player.look == 0 && player.image.dst.x >= image.position_x && player.image.dst.x <= image.position_x + image.largeur && player.image.dst.y >= image.position_y && player.image.dst.y <= image.position_y + 2 * player.image.hauteur){
		return 1;
	}


	else if(player.look == 2 && player.image.dst.x >= image.position_x + image.largeur && player.image.dst.x <= image.position_x + image.largeur + 2 *  player.image.largeur && player.image.dst.y <= image.position_y + image.hauteur && player.image.dst.y >= image.position_y){

		return 1;
	}

	else if(player.look == 3 && player.image.dst.x >= image.position_x - 2 * player.image.largeur && player.image.dst.x <= image.position_x + image.largeur && player.image.dst.y <= image.position_y + image.hauteur && player.image.dst.y >= image.position_y){

		return 1;
	}

  else if(player.look == 1 && player.image.dst.x >= image.position_x && player.image.dst.x <= image.position_x + image.largeur && player.image.dst.y <= image.position_y && player.image.dst.y >= image.position_y - 2 * player.image.hauteur){

		return 1;
	}

}


int main(int argc, char *argv[])
{
		if (SDL_Init(SDL_INIT_VIDEO) < 0){	// Initialisation de la SDL
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (SDL_Init(SDL_INIT_EVENTS) < 0){ // Initialisation des événements
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (TTF_Init() < 0){ // Initialisation de SDL_ttf
    	SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", TTF_GetError());
    	return EXIT_FAILURE;
		}
    //if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1){ //Initialisation de l'API Mixer
    //  printf("%s", Mix_GetError());
  //  }

    SDL_Window* pWindow;
		SDL_Renderer* pRenderer;
		SDL_Event events;
    SDL_Rect positionZozor; // Position de la souris

		if (SDL_CreateWindowAndRenderer(840, 840, SDL_WINDOW_SHOWN, &pWindow, &pRenderer) < 0)	// SDL_CreateWindowAndRenderer(taille_x, taille_x, window_settings, ptr_SDL_Window, ptr_SDL_Renderer)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        SDL_Quit();
        return EXIT_FAILURE;
    }

		const char* title;

		SDL_SetWindowTitle(pWindow, "SDL_Program");	// Nom de la fenêtre
		SDL_SetRenderDrawBlendMode(pRenderer, SDL_BLENDMODE_BLEND);

    load_image_t tab_load_image[NB_IMAGE];

    chargement_image(tab_load_image);

    player_t player = initialiser_joueur(player, pRenderer, tab_load_image);

		bool isOpen = true;
    int i;
		bool ramasser=false;

bool ramasser_open = false;
bool ramasser_open2 = false;
bool ramasser_open3 = false;


    //player.sprite = initialiser_image("link_idle_down.png",480,480,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
    //player.image = changement_image(player.image, "link_idle_down.png", 480, 480, 19*1.5, 23*1.5, pRenderer,tab_load_image);

 image_t map;
 image_t levier10;
 image_t levier20;
 image_t levier30;
 image_t lampe10;
 image_t lampe20;
 image_t lampe30;
 int xl1=150;
 int yl1=150;
 int xl2=650;
 int yl2=200;
 int xl3=150;
 int yl3=700;


 int xla1=400;
 int xla2=450;
 int xla3=500;
 int yla=400;





    SDL_Rect rect_map, src_map, dst_map;
    map.texture = initialiser_image_remastered(tab_load_image[57].surface,0,0,840,840,&src_map,&dst_map,pRenderer);

		levier10.texture = initialiser_image_remastered(tab_load_image[68].surface,xl1,yl1,32,24,&src_map,&dst_map,pRenderer);
		levier20.texture = initialiser_image_remastered(tab_load_image[68].surface,xl2,yl2,32,24,&src_map,&dst_map,pRenderer);
		levier30.texture = initialiser_image_remastered(tab_load_image[68].surface,xl3,yl3,32,24,&src_map,&dst_map,pRenderer);

		lampe10.texture = initialiser_image_remastered(tab_load_image[68].surface,xla1,yla,32,24,&src_map,&dst_map,pRenderer);
		lampe20.texture = initialiser_image_remastered(tab_load_image[68].surface,xla2,yla,32,24,&src_map,&dst_map,pRenderer);
		lampe30.texture = initialiser_image_remastered(tab_load_image[68].surface,xla3,yla,32,24,&src_map,&dst_map,pRenderer);

    SDL_Surface* couleur_image = IMG_Load("map_couleur.png");

    Mix_AllocateChannels(10);
    Mix_Volume(1,MIX_MAX_VOLUME/2);
    Mix_Chunk *sound_bullet;
		Mix_Chunk *sound_bow;
		Mix_Chunk *sound_arrow;
    Mix_Music *musique;
    musique = Mix_LoadMUS("zelda_theme.wav");
    Mix_VolumeMusic(MIX_MAX_VOLUME / 4);
    sound_bullet = Mix_LoadWAV("dspistol.wav");
		sound_bow = Mix_LoadWAV("bow_pull_sound.wav");
		sound_arrow = Mix_LoadWAV("arrow_sound.wav");
		Mix_Volume(3, MIX_MAX_VOLUME/4);
		//int levier1=0;
			int levier2=0;
			int levier3=0;
			int lampe1=0;
			int lampe2=0;
			int lampe3=0;
			int rechargement=1;
		int hauteur_carte=0;
		int largeur_carte=0;
		int compteur_map1=0;
		int compteur_map2=0;
    SDL_SetRenderDrawColor(pRenderer, 255, 255, 255, 255);

    Mix_PlayMusic(musique, -1);

		while(isOpen){	// Tant que l'application est active

			while(SDL_PollEvent(&events)){	// Boucle de gestion des événements de la SDL

				switch(events.type){	// Détection des événements de la SDL

					case SDL_WINDOWEVENT: // Fermes l'application si clique de la souris sur la croix rouge de la fenêtre
							 if (events.window.event == SDL_WINDOWEVENT_CLOSE){
								 isOpen = SDL_FALSE;
								 break;
							 }

          case SDL_MOUSEMOTION:
            positionZozor.x = events.motion.x;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            positionZozor.y = events.motion.y;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            break;

          case SDL_KEYDOWN:
            if (events.key.keysym.sym == SDLK_z){
							//SDL_Log("postion y du perso %d",player.image.position_y);
						 player.input.key_up_pressed = true;
						 if(player.image.position_y<0){
							// SDL_Log("changement de carte");
							 rechargement=1;
							 hauteur_carte--;
							player.image.dst.y=815;

						 }
            }
            if (events.key.keysym.sym == SDLK_s){
//SDL_Log("postion y du perso %d",player.image.position_y);
              player.input.key_down_pressed = true;
							if(player.image.position_y>784){
							 //SDL_Log("changement de carte");
							 rechargement=1;
							 hauteur_carte++;
							 player.image.dst.y=1;


						 }
            }
            if (events.key.keysym.sym == SDLK_q){
						//	SDL_Log("postion x du perso %d",player.image.position_x);
              player.input.key_left_pressed = true;
							if(player.image.position_x<2){
					//	SDL_Log("changement de carte");
						rechargement=1;
						largeur_carte--;
						player.image.dst.x=795;


					}
            }
            if (events.key.keysym.sym == SDLK_d){
						//	SDL_Log("postion x du perso %d",player.image.position_x);
						player.input.key_right_pressed = true;
						if(player.image.position_x>785){
					//	 SDL_Log("changement de carte");
						 rechargement=1;
						 largeur_carte++;
						 player.image.dst.x=5;



					 }
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              player.input.key_space_pressed = true;
            }
						if (events.key.keysym.sym == SDLK_LSHIFT){
              player.input.key_shift_pressed = true;
            }
            break;

          case SDL_KEYUP:
            if (events.key.keysym.sym == SDLK_z){
              player.input.key_up_pressed = false;
              player.look = 0;
              player.look_up = 1;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_s){
              player.input.key_down_pressed = false;
              player.look = 1;
              player.look_up = 0;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_q){
              player.input.key_left_pressed = false;
              player.look = 2;
              player.look_left = 1;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_d){
              player.input.key_right_pressed = false;
              player.look = 3;
              player.look_left = 0;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              player.input.key_space_pressed = false;
            }
						if (events.key.keysym.sym == SDLK_LSHIFT){
              player.input.key_shift_pressed = false;
            }
				  }

if(events.key.keysym.sym == SDLK_e ){
	if(est_a_cote(levier10, player)==1 && ramasser_open == false)
		ramasser_open = true;
	if(est_a_cote(levier20, player)==1 && ramasser_open2 == false)
		ramasser_open2 = true;
	if(est_a_cote(levier30, player)==1 && ramasser_open3 == false)
		ramasser_open3 = true;
}
					break;

			}

      SDL_RenderClear(pRenderer);
if(rechargement==1){

			if(hauteur_carte ==0 && largeur_carte==0){

							 map= changement_image (map, "map.png", 0, 0, 840, 840, pRenderer, tab_load_image);
							 couleur_image = IMG_Load("map_couleur.png");




 	 								}


 	 						 if(hauteur_carte ==1 && largeur_carte==0){
					 		 	map=changement_image (map, "carte1.png", 0, 0, 840, 840, pRenderer, tab_load_image);
					 			couleur_image = IMG_Load("carte2_hitbox.png");

 	 						 }

 	 						 if(hauteur_carte ==0 && largeur_carte==1){
							 map= changement_image (map, "carte3.png", 0, 0, 840, 840, pRenderer, tab_load_image);
							 couleur_image = IMG_Load("carte4_hitbox.png");


 	 						 }
 	 						 if(hauteur_carte ==1 && largeur_carte==1){
							 map= changement_image (map, "carte2.png", 0, 0, 840, 840, pRenderer, tab_load_image);

							 couleur_image = IMG_Load("carte3_hitbox.png");

 	 						 }
 	 						 if(hauteur_carte ==0 && largeur_carte==2){
								 map= changement_image (map, "carte4.png", 0, 0, 840, 840, pRenderer, tab_load_image);

								 couleur_image = IMG_Load("carte5_hitbox.png");

 	 						 }

 							 if(hauteur_carte ==1 && largeur_carte==2){

					 map= changement_image (map, "carte5.png", 0, 0, 840, 840, pRenderer, tab_load_image);
					 couleur_image = IMG_Load("carte6_hitbox.png");




					/* lampe10=changement_image (lampe10, "fleur.png", xl1, yl1, 32, 24, pRenderer, tab_load_image);
 					lampe20=changement_image (lampe20, "fleur.png", xl2, yl2, 32, 24, pRenderer, tab_load_image);
 					lampe30=changement_image (lampe30, "fleur.png", xl3, yl3, 32, 24, pRenderer, tab_load_image);

						afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
						afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
						afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);*/


					  }














rechargement=0;
}
// on affiche tout
afficher_image(pRenderer, map.texture, map.src, map.dst);


afficher_image(pRenderer, levier10.texture, levier10.src, levier10.dst);
afficher_image(pRenderer, levier20.texture, levier20.src, levier20.dst);
afficher_image(pRenderer, levier30.texture, levier30.src, levier30.dst);





if(hauteur_carte ==1 && largeur_carte==2){












if(ramasser_open == true){
levier10=changement_image (levier10, "arbust.png", xl1, yl1, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, levier10.texture, levier10.src, levier10.dst);
}
else{
 //levier10=changement_image (levier10, "fleur.png", xl1, yl1, 32, 24, pRenderer, tab_load_image);
 afficher_image(pRenderer, levier10.texture, levier10.src, levier10.dst);

}




if(ramasser_open2 == true){
	levier20=changement_image (levier20, "arbust.png", xl2, yl2, 32, 24, pRenderer, tab_load_image);
	afficher_image(pRenderer, levier20.texture, levier20.src, levier20.dst);

}
else{
	//levier20=changement_image (levier20, "fleur.png", xl2, yl2, 32, 24, pRenderer, tab_load_image);
	afficher_image(pRenderer, levier20.texture, levier20.src, levier20.dst);

}



if(ramasser_open3 == true){
	levier30=changement_image (levier30, "arbust.png", xl3, yl3, 32, 24, pRenderer, tab_load_image);
	afficher_image(pRenderer, levier30.texture, levier30.src, levier30.dst);

}
else{
	//levier30=changement_image (levier30, "fleur.png", xl3, yl3, 32, 24, pRenderer, tab_load_image);
	afficher_image(pRenderer, levier30.texture, levier30.src, levier30.dst);

}








if(ramasser_open==0 && ramasser_open2 == false && ramasser_open3 == false){//reponse
	lampe10=changement_image (lampe10, "arbust.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "arbust.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "arbust.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);


}

if(ramasser_open == false && ramasser_open2 == false && ramasser_open3 == true){//reponse
	lampe10=changement_image (lampe10, "arbust.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "arbust.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "fleur.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);


}
if(ramasser_open == false && ramasser_open2 == true && ramasser_open3 == false){//reponse
	lampe10=changement_image (lampe10, "arbust.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "fleur.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "arbust.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);

}
if(ramasser_open == true && ramasser_open2 == false && ramasser_open3 == false){//reponse
	lampe10=changement_image (lampe10, "fleur.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "arbust.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "arbust.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);

}
if(ramasser_open == false && ramasser_open2 == true && ramasser_open3 == true){//reponse
	lampe10=changement_image (lampe10, "arbust.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "fleur.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "fleur.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);

}


if(ramasser_open == true && ramasser_open2 == true && ramasser_open3 == false){//reponse
	lampe10=changement_image (lampe10, "fleur.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "fleur.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "arbust.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);


}


if(ramasser_open == true && ramasser_open2 == false && ramasser_open3 == true){//reponse
lampe10=changement_image (lampe10, "fleur.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
lampe20=changement_image (lampe20, "fleur.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
lampe30=changement_image (lampe30, "fleur.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
SDL_Log("ffesfsef");
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);

}



if(ramasser_open == true && ramasser_open2 == true && ramasser_open3 == true){//reponse
	lampe10=changement_image (lampe10, "arbust.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "arbust.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "arbust.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);


}


/*afficher_image(pRenderer, levier10.texture, levier10.src, levier10.dst);
afficher_image(pRenderer, levier20.texture, levier20.src, levier20.dst);
afficher_image(pRenderer, levier30.texture, levier30.src, levier30.dst);*/


}






#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "fonction_basiques.h"

// http://sdz.tdct.org/sdz/faire-des-rotations-avec-sdl-gfx.html
// apprendre rotation




int collision_perso(SDL_Rect player,SDL_Rect screen){
	//SDL_Log("test");
	return SDL_HasIntersection(&player, &screen );




}





int est_a_cote(image_t image, player_t player){
	if(player.look == 0 && player.image.dst.x >= image.position_x && player.image.dst.x <= image.position_x + image.largeur && player.image.dst.y >= image.position_y && player.image.dst.y <= image.position_y + 2 * player.image.hauteur){
		return 1;
	}


	else if(player.look == 2 && player.image.dst.x >= image.position_x + image.largeur && player.image.dst.x <= image.position_x + image.largeur + 2 *  player.image.largeur && player.image.dst.y <= image.position_y + image.hauteur && player.image.dst.y >= image.position_y){

		return 1;
	}

	else if(player.look == 3 && player.image.dst.x >= image.position_x - 2 * player.image.largeur && player.image.dst.x <= image.position_x + image.largeur && player.image.dst.y <= image.position_y + image.hauteur && player.image.dst.y >= image.position_y){

		return 1;
	}

  else if(player.look == 1 && player.image.dst.x >= image.position_x && player.image.dst.x <= image.position_x + image.largeur && player.image.dst.y <= image.position_y && player.image.dst.y >= image.position_y - 2 * player.image.hauteur){

		return 1;
	}

}








int main(int argc, char *argv[])
{
		if (SDL_Init(SDL_INIT_VIDEO) < 0){	// Initialisation de la SDL
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (SDL_Init(SDL_INIT_EVENTS) < 0){ // Initialisation des événements
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (TTF_Init() < 0){ // Initialisation de SDL_ttf
    	SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", TTF_GetError());
    	return EXIT_FAILURE;
		}
    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1){ //Initialisation de l'API Mixer
      printf("%s", Mix_GetError());
    }

    SDL_Window* pWindow;
		SDL_Renderer* pRenderer;
		SDL_Event events;
    SDL_Rect positionZozor; // Position de la souris

		if (SDL_CreateWindowAndRenderer(840, 840, SDL_WINDOW_SHOWN, &pWindow, &pRenderer) < 0)	// SDL_CreateWindowAndRenderer(taille_x, taille_x, window_settings, ptr_SDL_Window, ptr_SDL_Renderer)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        SDL_Quit();
        return EXIT_FAILURE;
    }

    player_t player = initialiser_joueur(player);

		bool isOpen = true;
		const char* title;

    int i;
    case_t screen[196];
		case_t rect[200];//liste des rectangles
    remplir_screen(screen);

    initialiser_white_screen(screen, pRenderer);

		SDL_SetWindowTitle(pWindow, "SDL_Program");	// Nom de la fenêtre
		SDL_SetRenderDrawBlendMode(pRenderer, SDL_BLENDMODE_BLEND);

    player.sprite = initialiser_image("link_idle_down.png",480,480,840,840,&player.src,&player.dst,pRenderer);

    SDL_Rect src_bullet1,dst_bullet1;
    SDL_Texture* pTextureImage_bullet;

    SDL_Texture *pTexture_tile1[500];
    SDL_Rect dst_tile1[500];
    int nb_pTexture_tile1 = 0;

    SDL_Texture *pTexture_tile2[500];
    SDL_Rect dst_tile2[500];
    int nb_pTexture_tile2 = 0;

		int levier1=0;
		int levier2=0;
		int levier3=0;
		int lampe1=0;
		int lampe2=0;
		int lampe3=0;

		bool ramasser=false;

bool ramasser_open = false;
bool ramasser_open2 = false;
bool ramasser_open3 = false;


image_t map;
 image_t levier10;
 image_t levier20;
 image_t levier30;
 image_t lampe10;
 image_t lampe20;
 image_t lampe30;

 link1.image = changement_image(link1.image, "link_idle_right.png", 300, 300, 40, 40, pRenderer, tab_load_image);

 levier10 = changement_image(levier10, "fleur.png", 100, 400, 32, 30, pRenderer, tab_load_image);
 levier20 = changement_image(levier20, "fleur.png", 300, 400, 32, 30, pRenderer, tab_load_image);
 levier30 = changement_image(levier30, "fleur.png", 400, 400, 32, 30, pRenderer, tab_load_image);
 lampe10 = changement_image(lampe10, "fleur.png", 400, 400, 32, 30, pRenderer, tab_load_image);
 lampe20 = changement_image(lampe20, "fleur.png", 400, 400, 32, 30, pRenderer, tab_load_image);
 lampe30 = changement_image(lampe30, "fleur.png", 400, 400, 32, 30, pRenderer, tab_load_image);





		SDL_Texture* map1;
		    SDL_Rect rect_map1, src_map1, dst_map1;
		    map1 = initialiser_image("carte1.png",0,0,840,840,&src_map1,&dst_map1,pRenderer);



	SDL_Texture* map2;
				 SDL_Rect rect_map2, src_map2, dst_map2;
				 map2 = initialiser_image("carte2.png",0,0,840,840,&src_map2,&dst_map2,pRenderer);



	SDL_Texture* map3;
				  SDL_Rect rect_map3, src_map3, dst_map3;
				  map3 = initialiser_image("carte3.png",0,0,840,840,&src_map3,&dst_map3,pRenderer);



		SDL_Texture* map4;
			   SDL_Rect rect_map4, src_map4, dst_map4;
				 map4 = initialiser_image("carte4.png",0,0,840,840,&src_map4,&dst_map4,pRenderer);



		SDL_Texture* map5;
				 SDL_Rect rect_map5, src_map5, dst_map5;
				 map5 = initialiser_image("carte5.png",0,0,840,840,&src_map5,&dst_map5,pRenderer);

	 SDL_Texture* map6;
			 	 SDL_Rect rect_map6, src_map6, dst_map6;
			 	map6 = initialiser_image("carte_levier.png",0,0,840,840,&src_map6,&dst_map6,pRenderer);


//levier de gauche
				SDL_Texture* objet1;
		 			 	 SDL_Rect rect_map7, src_map7, dst_map7;
		 			 	objet1 = initialiser_image("fleur.png",100,400,32,30,&src_map7,&dst_map7,pRenderer);

				SDL_Texture* objet2;
							SDL_Rect rect_map8, src_map8, dst_map8;
							objet2 = initialiser_image("arbust.png",100,400,32,24,&src_map8,&dst_map8,pRenderer);

//levier de droite

SDL_Texture* objet3;
		 SDL_Rect rect_map9, src_map9, dst_map9;
		objet3 = initialiser_image("fleur.png",400,400,32,30,&src_map9,&dst_map9,pRenderer);

SDL_Texture* objet4;
			SDL_Rect rect_map10, src_map10, dst_map10;
			objet4 = initialiser_image("arbust.png",400,400,32,24,&src_map10,&dst_map10,pRenderer);

// levier millieux


SDL_Texture* objet5;
		 SDL_Rect rect_map11, src_map11, dst_map11;
		objet5 = initialiser_image("fleur.png",300,400,32,30,&src_map11,&dst_map11,pRenderer);

SDL_Texture* objet6;
			SDL_Rect rect_map12, src_map12, dst_map12;
			objet6 = initialiser_image("arbust.png",300,400,32,24,&src_map12,&dst_map12,pRenderer);



//lampe 1
SDL_Texture* objet7;
		 SDL_Rect rect_map13, src_map13, dst_map13;
		objet7 = initialiser_image("fleur.png",100,200,32,30,&src_map13,&dst_map13,pRenderer);

SDL_Texture* objet8;
			SDL_Rect rect_map14, src_map14, dst_map14;
			objet8 = initialiser_image("arbust.png",100,200,32,24,&src_map14,&dst_map14,pRenderer);


//lampe 2
SDL_Texture* objet9;
		 SDL_Rect rect_map15, src_map15, dst_map15;
		objet9 = initialiser_image("fleur.png",300,200,32,30,&src_map15,&dst_map15,pRenderer);

SDL_Texture* objet10;
			SDL_Rect rect_map16, src_map16, dst_map16;
			objet10 = initialiser_image("arbust.png",300,200,32,24,&src_map16,&dst_map16,pRenderer);


//lampe 3
SDL_Texture* objet11;
		 SDL_Rect rect_map17, src_map17, dst_map17;
		objet11 = initialiser_image("fleur.png",400,200,32,30,&src_map17,&dst_map17,pRenderer);

SDL_Texture* objet12;
			SDL_Rect rect_map18, src_map18, dst_map18;
			objet12 = initialiser_image("arbust.png",400,200,32,24,&src_map18,&dst_map18,pRenderer);




    Mix_AllocateChannels(10);
    Mix_Volume(1,MIX_MAX_VOLUME/2);
    Mix_Chunk *sound_bullet;
		Mix_Chunk *sound_bow;
		Mix_Chunk *sound_arrow;
    Mix_Music *musique;
    musique = Mix_LoadMUS("zelda_theme.wav");
    Mix_VolumeMusic(MIX_MAX_VOLUME / 4);
    sound_bullet = Mix_LoadWAV("dspistol.wav");
		sound_bow = Mix_LoadWAV("bow_pull_sound.wav");
		sound_arrow = Mix_LoadWAV("arrow_sound.wav");
		Mix_Volume(3, MIX_MAX_VOLUME/4);

		// BouleBleu qui tourne autour du perso
		SDL_Rect src_boule_bleu,dst_boule_bleu;
    SDL_Texture* pTexture_boule_bleu;
int collision_mur;


			int numero_carte=2;
      FILE *fichier;
      char carte1[20]="carte1.txt";
      char carte2[20]="carte2.txt";
      char carte3[20]="carte3.txt";
      char carte4[20]="carte4.txt";

      int rechargement=1;
      int hauteur_carte=0;
      int largeur_carte=0;
			int compteur_map1=0;
    	int compteur_map2=0;
			int n_sprite;
      int mat_carte[10][10];






    SDL_SetRenderDrawColor(pRenderer, 255, 255, 255, 255);

    Mix_PlayMusic(musique, -1);

		while(isOpen){	// Tant que l'application est active

			while(SDL_PollEvent(&events)){	// Boucle de gestion des événements de la SDL

				switch(events.type){	// Détection des événements de la SDL

					case SDL_WINDOWEVENT: // Fermes l'application si clique de la souris sur la croix rouge de la fenêtre
							 if (events.window.event == SDL_WINDOWEVENT_CLOSE){
								 isOpen = SDL_FALSE;
								 break;
							 }

          case SDL_MOUSEMOTION:
            positionZozor.x = events.motion.x;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            positionZozor.y = events.motion.y;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            break;

          case SDL_KEYDOWN:
            if (events.key.keysym.sym == SDLK_z){
							 SDL_Log("postion y du perso %d",player.dst.y);
              player.input.key_up_pressed = true;
							if(player.dst.y<0){
                SDL_Log("changement de carte");
                rechargement=1;
                hauteur_carte--;
                player.dst.y=815;


              }
            }
            if (events.key.keysym.sym == SDLK_s){
							SDL_Log("postion y du perso %d",player.dst.y);
              player.input.key_down_pressed = true;
							if(player.dst.y>784){
							 SDL_Log("changement de carte");
							 rechargement=1;
							 hauteur_carte++;
							 player.dst.y=1;


						 }
            }
            if (events.key.keysym.sym == SDLK_q){
							SDL_Log("postion x du perso %d",player.dst.x);
              player.input.key_left_pressed = true;
							if(player.dst.x<0){
						SDL_Log("changement de carte");
						rechargement=1;
						largeur_carte--;
						player.dst.x=795;


					}
            }
            if (events.key.keysym.sym == SDLK_d){
							SDL_Log("postion x du perso %d",player.dst.x);
              player.input.key_right_pressed = true;
							if(player.dst.x>785){
							 SDL_Log("changement de carte");
							 rechargement=1;
							 largeur_carte++;
							 player.dst.x=5;


						 }
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              player.input.key_space_pressed = true;
            }
						if (events.key.keysym.sym == SDLK_LSHIFT){
              player.input.key_shift_pressed = true;
            }
            break;

          case SDL_KEYUP:
            if (events.key.keysym.sym == SDLK_z){
              player.input.key_up_pressed = false;
              player.look = 0;
              player.look_up = 1;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_s){
              player.input.key_down_pressed = false;
              player.look = 1;
              player.look_up = 0;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_q){
              player.input.key_left_pressed = false;
              player.look = 2;
              player.look_left = 1;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_d){
              player.input.key_right_pressed = false;
              player.look = 3;
              player.look_left = 0;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              player.input.key_space_pressed = false;
            }
						if (events.key.keysym.sym == SDLK_LSHIFT){
              player.input.key_shift_pressed = false;
            }



					if(events.key.keysym.sym == SDLK_e ){

													if(player.look == 0 && player.dst.x >= 100-10 && player.dst.x <= 100+40 && player.dst.y <= 400+40 && player.dst.y >= 400-10 && ramasser_open == false){
														ramasser_open = true;
													}
													else if(player.look == 1 && player.dst.x >= 100-10 && player.dst.x <= 100+40 && player.dst.y <= 400+40 && player.dst.y >= 400-10 && ramasser_open == false){
														ramasser_open = true;
													}
													else if(player.look == 2 && player.dst.x >= 100-10 && player.dst.x <= 100+40 && player.dst.y <= 400+40 && player.dst.y >= 400-10 && ramasser_open == false){
														ramasser_open = true;
													}
													else if(player.look == 3 && player.dst.x >= 100-10 && player.dst.x <= 100+40 && player.dst.y <= 400+40 && player.dst.y >= 400-10 && ramasser_open == false){
														ramasser_open = true;
													}
													else{
														ramasser_open = false;
													}

														/*if(levier1==0){
															levier1=1;
														}*/
														/*else if(levier1==1){
															levier1=0;
														}*/




												//		pTextureImage_link1 = i:nitialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
													//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);



														/*else if(levier1==1){
															levier1=0;
														}*/


													//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
													//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);



														/*else if(levier1==1){
															levier1=0;
														}*/


													//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
													//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);



														/*else if(levier1==1){
															levier1=0;
														}*/


													//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
														//case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);


/*-----------------------fin levier 1 ---------------------*/

										if(player.look == 0 && player.dst.x >= 400-10 && player.dst.x <= 400+40 && player.dst.y <= 400+40 && player.dst.y >= 400-10 && ramasser_open2 == false){
											ramasser_open2 = true;
										}

										else if(player.look == 1 && player.dst.x >= 400-30 && player.dst.x <= 400+40 && player.dst.y <= 400 && player.dst.y >=400-70 && ramasser_open2 == false){
											ramasser_open2 = true;
										}

										else if(player.look == 2 && player.dst.x >= 400-30 && player.dst.x <= 400+40 && player.dst.y <= 400 && player.dst.y >=400-70 && ramasser_open2 == false){
											ramasser_open2 = true;
										}

										else if(player.look == 3 && player.dst.x >= 400-30 && player.dst.x <= 400+40 && player.dst.y <= 400 && player.dst.y >=400-70 && ramasser_open2 == false){
											ramasser_open2 = true;
										}
										else{
											ramasser_open2 = false;
										}


										/*-------levier 3--------*/

										if(player.look == 0 && player.dst.x >= 300-10 && player.dst.x <= 300+40 && player.dst.y <= 400+40 && player.dst.y >= 400-10 && ramasser_open3 == false){
											ramasser_open3 = true;
										}

										else if(player.look == 1 && player.dst.x >= 300-30 && player.dst.x <= 300+40 && player.dst.y <= 400 && player.dst.y >=400-70 && ramasser_open3 == false){
											ramasser_open3 = true;
										}

										else if(player.look == 2 && player.dst.x >= 300-30 && player.dst.x <= 300+40 && player.dst.y <= 400 && player.dst.y >=400-70 && ramasser_open3 == false){
											ramasser_open3 = true;
										}

										else if(player.look == 3 && player.dst.x >= 300-30 && player.dst.x <= 300+40 && player.dst.y <= 400 && player.dst.y >=400-70 && ramasser_open3 == false){
											ramasser_open3 = true;
										}
										else{
											ramasser_open3 = false;
										}









												}
												break;
											}

			}

      SDL_RenderClear(pRenderer);	// Rempli la fenêtre
		//	SDL_Log("hauteur_carte = %d",hauteur_carte);
	 	// SDL_Log("largeur_carte= %d ",largeur_carte);

	 	// SDL_Log("mat_carte %d",mat_carte[hauteur_carte][largeur_carte]);

	 					 if(hauteur_carte ==0 && largeur_carte==0){  //si la carte est activer
	 						// SDL_Log("chargement de la carte 1 ");

	 										 afficher_image(pRenderer, map1, src_map1, dst_map1);

	 								}
	 								//chargement de la carte [1][0]


	 						 if(hauteur_carte ==1 && largeur_carte==0){
	 						//	 SDL_Log("chargement de la carte 2  ");
	 afficher_image(pRenderer, map2, src_map2, dst_map2);


	 						 }

	 						 if(hauteur_carte ==0 && largeur_carte==1){
	 							// SDL_Log("chargement de la carte 3  ");
	 afficher_image(pRenderer, map4, src_map4, dst_map4);


	 						 }
	 						 if(hauteur_carte ==1 && largeur_carte==1){
	 							// SDL_Log("chargement de la carte 4  ");
	 afficher_image(pRenderer, map3, src_map3, dst_map3);


	 						 }
	 						 if(hauteur_carte ==0 && largeur_carte==2){
	 							// SDL_Log("chargement de la carte 4  ");
	 afficher_image(pRenderer, map5, src_map5, dst_map5);


	 						 }

							 if(hauteur_carte ==1 && largeur_carte==2){
							//	SDL_Log("chargement de la carte enigme  ");

	afficher_image(pRenderer, map6, src_map6, dst_map6);


/*------------debut enigme-----------*/


afficher_image(pRenderer, objet7, src_map13, dst_map13);
afficher_image(pRenderer, objet9, src_map15, dst_map15);
afficher_image(pRenderer, objet11, src_map17, dst_map17);


if(ramasser_open == true){
	afficher_image(pRenderer, objet2, src_map8, dst_map8);
}
else{
	afficher_image(pRenderer, objet1, src_map7, dst_map7);
}

if(ramasser_open2 == true){
	afficher_image(pRenderer, objet4, src_map10, dst_map10);
}
else{
	afficher_image(pRenderer, objet3, src_map9, dst_map9);
}

if(ramasser_open3 == true){
	afficher_image(pRenderer, objet6, src_map12, dst_map12);
}
else{
	afficher_image(pRenderer, objet5, src_map11, dst_map11);
}






}
if(ramasser_open == true && ramasser_open2 == false && ramasser_open3 == true){//reponse
	afficher_image(pRenderer, objet8, src_map14, dst_map14);
	afficher_image(pRenderer, objet10, src_map16, dst_map16);
	afficher_image(pRenderer, objet12, src_map18, dst_map18);

}

if(ramasser_open == false && ramasser_open2 == false && ramasser_open3 == true){//reponse
	afficher_image(pRenderer, objet7, src_map13, dst_map13);
	afficher_image(pRenderer, objet9, src_map15, dst_map15);
	afficher_image(pRenderer, objet12, src_map18, dst_map18);

}
if(ramasser_open == false && ramasser_open2 == true && ramasser_open3 == false){//reponse
	afficher_image(pRenderer, objet8, src_map14, dst_map14);
	afficher_image(pRenderer, objet9, src_map15, dst_map15);
	afficher_image(pRenderer, objet12, src_map18, dst_map18);

}



/*--------------------- fin-------------------*/








      	player = update_arrow(player);
				player = check_and_reset_animation(player);
				if (player.input.key_space_pressed == true) {
					player = player_shooting_bow (player, sound_bow, sound_arrow, pRenderer);
				}
				else{
					if (player.input.key_shift_pressed == true){
						player.speed = 2;
						player.limite_compteur_animation = 20;
					}
					else{
						player.speed = 1;
						player.limite_compteur_animation = 25;
					}
					player = player_moving(player, pRenderer,collision_mur);
				}

      for(i=0;i<19;i++){
        if (player.live_bullet[i] != -1){
          afficher_image(pRenderer, player.pTexture_bullet[i], player.src_bullet[i], player.dst_bullet[i]);
        }
      }




















rect[0].rectangle.x=100;
rect[0].rectangle.y=100;
rect[0].rectangle.w=100;
rect[0].rectangle.h=100;













				SDL_SetRenderDrawColor(pRenderer, 14, 87, 58, 25); // choisir une couleur
										SDL_RenderFillRect(pRenderer,&rect[0].rectangle);



			//	SDL_SetRenderDrawColor(pRenderer, 14, 87, 58, 25); // choisir une couleur
//SDL_RenderFillRect(pRenderer,&rect[1]);
					collision_mur=collision_perso(rect[0].rectangle,player.dst);

//SDL_Log("%d",collision_mur);

      afficher_image(pRenderer, player.sprite, player.src, player.dst);




		//SDL_LireCouleur(pRenderer, 10, 10);












			SDL_RenderPresent(pRenderer); // Met à jour la fenêtre

      SDL_Delay(5);

		}

    Mix_FreeChunk(sound_bullet);
		Mix_FreeChunk(sound_arrow);
		Mix_FreeChunk(sound_bow);
    Mix_FreeMusic(musique);
    Mix_CloseAudio(); //Fermeture de l'API
		SDL_DestroyRenderer(pRenderer);
		SDL_DestroyWindow(pWindow);
    TTF_Quit();
    SDL_Quit(); // Arrêt de la SDL (libération de la mémoire).

    return 0;
}
























      	player = update_arrow(player);
				player = check_and_reset_animation(player);
				if (player.input.key_space_pressed == true) {
					player = player_shooting_bow(player, sound_bow, sound_arrow, pRenderer, tab_load_image);
				}
				else{
					if (player.input.key_shift_pressed == true){
						player.speed = 2;
						player.limite_compteur_animation = 20;
					}
					else{
						player.speed = 1;
						player.limite_compteur_animation = 25;
					}
					player = player_moving(player, pRenderer, couleur_image, tab_load_image);
				}

      for(i=0;i<19;i++){
        if (player.live_bullet[i] != -1){
          afficher_image(pRenderer, player.pTexture_bullet[i], player.src_bullet[i], player.dst_bullet[i]);
        }
      }

      afficher_image(pRenderer, player.image.texture, player.image.src, player.image.dst);

			SDL_RenderPresent(pRenderer); // Met à jour la fenêtre

      SDL_Delay(5);

		}



    detruire_image(tab_load_image);
    SDL_FreeSurface(couleur_image);
   Mix_FreeChunk(sound_bullet);
		Mix_FreeChunk(sound_arrow);
		Mix_FreeChunk(sound_bow);
   Mix_FreeMusic(musique);
    Mix_CloseAudio(); //Fermeture de l'API
		SDL_DestroyRenderer(pRenderer);
		SDL_DestroyWindow(pWindow);
    TTF_Quit();
    SDL_Quit(); // Arrêt de la SDL (libération de la mémoire).

    return 0;

}
