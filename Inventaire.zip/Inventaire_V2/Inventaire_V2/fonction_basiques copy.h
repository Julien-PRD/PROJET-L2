typedef struct case_s{
  int numero;
  SDL_Rect rectangle;
  SDL_Rect src;
  SDL_Rect dst;
  SDL_Texture* texture;
}case_t;

typedef struct projectile_s{
  int direction;
  SDL_Rect rectangle;
  SDL_Rect dst;
  SDL_Rect src;
  SDL_Texture* texture;
}projectile_t;

SDL_Texture* initialiser_image(char * nom_image, int position_x, int position_y, int largeur, int hauteur, SDL_Rect *src, SDL_Rect *dst, SDL_Renderer* pRenderer);

void afficher_image(SDL_Renderer* pRenderer, SDL_Texture* pTextureImage, SDL_Rect src, SDL_Rect dst);

int est_dedans(SDL_Rect objet, SDL_Event events);

void remplir_screen (case_t screen_to_full[196]);

int find_case (SDL_Rect ecran_to_find[196], SDL_Event events);

int find_screen (case_t screen_to_find[196], SDL_Event events);
