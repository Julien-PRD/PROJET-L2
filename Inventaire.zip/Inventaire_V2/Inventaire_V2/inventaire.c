#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "inventaire.h"
//#include "fonction_basiques.h"



void remplir_inventaire (inventaire_t caseinv[21]){
    int add_x = 51;
    int add_y = 499;
    for(int i=0;i<21;i++){
      caseinv[i].dst.x = add_x;
      caseinv[i].dst.y = add_y;
      caseinv[i].dst.w = 55;
      caseinv[i].dst.h = 55;
      //caseinv[i].src.x = caseinv[i].src.y = caseinv[i].src.w = caseinv[i].src.h = 0;
      add_x = add_x + 63;
      if(add_x == 492){
        add_x = 51;
        add_y = add_y + 63;
      }
  //fprintf(stdout,"Case nb : %d de x : %d et y : %d \n", i, caseinv[i].dst.x, caseinv[i].dst.y);
    }
		//fprintf(stdout, "case nb 0 x: %d et y: %d\n", caseinv[0].dst.x, caseinv[0].dst.y);

}

image_t detruire_image2(image_t image){
	image.texture = NULL;
	return image;
}


int est_a_cote(image_t image, player_t player){
	if(player.look == 0 && player.image.dst.x >= image.position_x && player.image.dst.x <= image.position_x + image.largeur && player.image.dst.y >= image.position_y && player.image.dst.y <= image.position_y + 2 * player.image.hauteur){
		return 1;
	}


	else if(player.look == 2 && player.image.dst.x >= image.position_x + image.largeur && player.image.dst.x <= image.position_x + image.largeur + 2 *  player.image.largeur && player.image.dst.y <= image.position_y + image.hauteur && player.image.dst.y >= image.position_y){

		return 1;
	}

	else if(player.look == 3 && player.image.dst.x >= image.position_x - 2 * player.image.largeur && player.image.dst.x <= image.position_x + image.largeur && player.image.dst.y <= image.position_y + image.hauteur && player.image.dst.y >= image.position_y){

		return 1;
	}

  else if(player.look == 1 && player.image.dst.x >= image.position_x && player.image.dst.x <= image.position_x + image.largeur && player.image.dst.y <= image.position_y && player.image.dst.y >= image.position_y - 2 * player.image.hauteur){

		return 1;
	}

}
