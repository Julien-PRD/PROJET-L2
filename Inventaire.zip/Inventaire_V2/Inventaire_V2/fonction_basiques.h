#define NB_IMAGE 59

typedef struct image_s{
  char * nom_image;
  int position_x, position_y;
  int largeur, hauteur;
  SDL_Rect src,dst;
  SDL_Texture* texture;
}image_t;

typedef struct load_image_s{

  char * nom_image;
  SDL_Surface* surface;

}load_image_t;

typedef struct case_s{
  int numero;
  SDL_Rect rectangle;
  SDL_Rect src;
  SDL_Rect dst;
  SDL_Texture* texture;
}case_t;

typedef struct projectile_s{
  int direction;
  SDL_Rect rectangle;
  SDL_Rect dst;
  SDL_Rect src;
  SDL_Texture* texture;
}projectile_t;

typedef struct input_s{
  bool key_up_pressed, key_down_pressed, key_left_pressed, key_right_pressed;
  bool key_space_pressed, key_shift_pressed;
}input_t;

typedef struct player_s{
  SDL_Texture* sprite;
  SDL_Rect dst;
  SDL_Rect src;
  int speed;
  bool idle, bullet_shot;
  int changement_frame, animation, animation_shoot, old_animation, compteur_animation, compteur_animation_shoot;
  int limite_compteur_animation, limite_compteur_animation_shoot;
  int look, look_up, look_down, look_left, look_right;
  int direction;

  int nb_bullet;
  SDL_Texture *pTexture_bullet[20];
  SDL_Rect dst_bullet[20];
  int dir_bullet[20];
  int live_bullet[20];
  SDL_Rect src_bullet[20];

  SDL_Rect rectangle;
  input_t input;
  image_t image;
}player_t;



SDL_Texture* initialiser_image(char * nom_image, int position_x, int position_y, int largeur, int hauteur, SDL_Rect *src, SDL_Rect *dst, SDL_Renderer* pRenderer);

SDL_Texture* initialiser_image_remastered(SDL_Surface* surface, int position_x, int position_y, int largeur, int hauteur, SDL_Rect *src, SDL_Rect *dst, SDL_Renderer* pRenderer);

void chargement_image(load_image_t tab_load_image[NB_IMAGE]);

void detruire_image(load_image_t tab_load_image[NB_IMAGE]);

Uint32 getpixel(SDL_Surface *surface, int x, int y);

player_t initialiser_joueur(player_t player, SDL_Renderer* pRenderer, load_image_t tab_load_image[NB_IMAGE]);

void afficher_image(SDL_Renderer* pRenderer, SDL_Texture* pTextureImage, SDL_Rect src, SDL_Rect dst);

int est_dedans(SDL_Rect objet, SDL_Event events);

int find_case (SDL_Rect ecran_to_find[196], SDL_Event events);

int find_screen (case_t screen_to_find[196], SDL_Event events);

player_t check_and_reset_animation (player_t player);

player_t update_arrow (player_t player);

player_t player_moving (player_t player, SDL_Renderer* pRenderer, SDL_Surface* couleur_image, load_image_t tab_load_image[NB_IMAGE]);

player_t player_shooting_bow (player_t player, Mix_Chunk *sound_bow, Mix_Chunk *sound_arrow, SDL_Renderer* pRenderer, load_image_t tab_load_image[NB_IMAGE]);

image_t changement_image (image_t image, char * nouveau_nom_image, int nouvelle_position_x, int nouvelle_position_y, int nouvelle_largeur, int nouvelle_hauteur, SDL_Renderer* pRenderer, load_image_t tab_load_image[NB_IMAGE]);
