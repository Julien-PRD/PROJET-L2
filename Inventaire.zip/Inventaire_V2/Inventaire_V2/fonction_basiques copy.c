#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "fonction_basiques.h"

SDL_Texture* initialiser_image(char * nom_image, int position_x, int position_y, int largeur, int hauteur, SDL_Rect *src, SDL_Rect *dst, SDL_Renderer* pRenderer){

		SDL_Surface* image = IMG_Load(nom_image); // Pointeur sur une SDL_Surface qui contient l'image
		if(!image) {															// Gestion de l'erreur si l'image ne charge pas
    	printf("IMG_Load: %s\n", IMG_GetError());
		}
		SDL_Texture* pTextureImage = SDL_CreateTextureFromSurface(pRenderer, image);	// On crée une texture depuis l'image
		SDL_FreeSurface(image);	// On libère le SDL_Surface
		src->x = src->y = src->w = src->h = 0; // x,y,largeur,hauteur de l'image de base
    dst->x = position_x;
    dst->y = position_y;
    dst->w = largeur;
    dst->h = hauteur;
		SDL_QueryTexture(pTextureImage, NULL, NULL, &src->w, &src->h);	// on prépare la texture
    return pTextureImage;

}

void afficher_image(SDL_Renderer* pRenderer, SDL_Texture* pTextureImage, SDL_Rect src, SDL_Rect dst){
  SDL_RenderCopy(pRenderer, pTextureImage, &src, &dst);
}


int est_dedans(SDL_Rect objet, SDL_Event events){

  if (events.button.x >= objet.x && events.button.x <= objet.x+objet.w && events.button.y >= objet.y && events.button.y <= objet.y+objet.h){
    // printf("est_dedans 1 \n");
    return 1;
  }
  else {
    //printf("est_dedans 0 \n");
    return 0;
  }

}

void remplir_screen (case_t screen_to_full[196]){
    int add_x = 0;
    int add_y = 0;
    for(int i=0;i<196;i++){
      screen_to_full[i].rectangle.x = add_x;
      screen_to_full[i].rectangle.y = add_y;
      screen_to_full[i].rectangle.w = 60;
      screen_to_full[i].rectangle.h = 60;
      screen_to_full[i].src.x = screen_to_full[i].src.y = screen_to_full[i].src.w = screen_to_full[i].src.h = 0;
      add_x = add_x + 60;
      if(add_x == 840){
        add_x = 0;
        add_y = add_y + 60;
      }
  //  fprintf(stdout,"Case nb : %d de x : %d et y : %d \n", i, ecran_to_full[i].x, ecran_to_full[i].y);
    }
}

int find_case (SDL_Rect ecran_to_find[196], SDL_Event events){
  int i;
  for(i=0;i<196;i++){
    if(est_dedans(ecran_to_find[i],events)){
      fprintf(stdout,"Trouvé ! case nb : %d de x : %d et y : %d \n", i, ecran_to_find[i].x, ecran_to_find[i].y);
      return i;
    }
  }
}

int find_screen (case_t screen_to_find[196], SDL_Event events){
  int i;
  for(i=0;i<196;i++){
    if(est_dedans(screen_to_find[i].rectangle,events)){
      fprintf(stdout,"Trouvé ! case nb : %d de x : %d et y : %d \n", i, screen_to_find[i].rectangle.x, screen_to_find[i].rectangle.y);
      return i;
    }
  }
}
