#include "fonction_basiques.h"

typedef struct objet_s{
  char * nom_objet;
  char * description;
  image_t image;
  int id;
}objet_t;

typedef struct inventaire_s{
    bool is_empty;
    SDL_Rect rectangle;
    SDL_Rect dst;
    SDL_Rect src;
    objet_t objet;
}inventaire_t;

typedef struct liste_s{
  objet_t tab[8];
  bool est_ramasser[8];
  int emplacement[8];
}liste_t;


void remplir_inventaire (inventaire_t caseinv[21]);

image_t detruire_image2(image_t image);

int est_a_cote(image_t image, player_t player);
