#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "fonction_basiques.h"

int main(int argc, char *argv[])
{
		if (SDL_Init(SDL_INIT_VIDEO) < 0){	// Initialisation de la SDL
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (SDL_Init(SDL_INIT_EVENTS) < 0){ // Initialisation des événements
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (TTF_Init() < 0){ // Initialisation de SDL_ttf
    	SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", TTF_GetError());
    	return EXIT_FAILURE;
		}

		SDL_Window* pWindow;
		SDL_Renderer* pRenderer;
		SDL_Event events;
    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1) //Initialisation de l'API Mixer
     {
      printf("%s", Mix_GetError());
      }

     /* Contenu Ajouté */
    SDL_Rect positionZozor; // Position de la souris

		bool isOpen = true;
    bool key_up_pressed = false;
    bool key_down_pressed = false;
    bool key_left_pressed = false;
    bool key_right_pressed = false;
    bool shooting = false;
    bool bullet_shot = false;
    bool idle = true;
		const char* title;

    int bonjour_mario = 1;
    int selection_tile = -1;
    int i = 0;
    int box = 0;
    int look_down = 1;
    int look_up = 0;
    int look_left = 0;
    int look_right = 0;
    int changement_frame = 0;
    SDL_Rect rect_NULL = {0,0,0,0};

    int speed = 0.6;
    int look = 1; // up = 0 , down = 1 , left = 2 , right = 3
    int animation = 0;
    int animation_shoot = 0;
    int old_animation = 0;
    int compteur_animation = 0;
    int compteur_animation_shoot = 0;
    const int limite_compteur_animation = 25;

    case_t screen[196];
    remplir_screen(screen);

    for(i=0;i<196;i++){
      screen[i].texture = initialiser_image("white.png",screen[i].rectangle.x,screen[i].rectangle.y,60,60,&screen[i].src,&(screen[i].dst),pRenderer);
    }

		if (SDL_CreateWindowAndRenderer(840, 840, SDL_WINDOW_SHOWN, &pWindow, &pRenderer) < 0)	// SDL_CreateWindowAndRenderer(taille_x, taille_x, window_settings, ptr_SDL_Window, ptr_SDL_Renderer)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        SDL_Quit();
        return EXIT_FAILURE;
    }

		SDL_SetWindowTitle(pWindow, "SDL_Program");	// Nom de la fenêtre
		SDL_SetRenderDrawBlendMode(pRenderer, SDL_BLENDMODE_BLEND);

    SDL_Rect src1,dst1;
    SDL_Texture* pTextureImage = initialiser_image("doom_down.png",480,480,45,56,&src1,&dst1,pRenderer);
    SDL_Rect src_tile1,dst_tile11;
    SDL_Texture* pTextureImage_tile1 = initialiser_image("tile1.png",0,0,60,60,&src_tile1,&dst_tile11,pRenderer);
    SDL_Rect src_tile2,dst_tile22;
    SDL_Texture* pTextureImage_tile2 = initialiser_image("tile2.png",0,60,60,60,&src_tile2,&dst_tile22,pRenderer);

    SDL_Rect src_bullet1,dst_bullet1;
    SDL_Texture* pTextureImage_bullet;

    SDL_Texture *pTexture_bullet[20];
    SDL_Rect dst_bullet[20];
    int dir_bullet[20];
    SDL_Rect src_bullet[20];
    for (int i = 0; i<19 ;i++){
      src_bullet[i].x = src_bullet[i].y = src_bullet[i].h = src_bullet[i].w = 0;
    }
    int live_bullet[20] = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
    int nb_bullet = 0;

    SDL_Texture *pTexture_tile1[500];
    SDL_Rect dst_tile1[500];
    int nb_pTexture_tile1 = 0;

    SDL_Texture *pTexture_tile2[500];
    SDL_Rect dst_tile2[500];
    int nb_pTexture_tile2 = 0;

    Mix_AllocateChannels(10);
    Mix_Volume(1,MIX_MAX_VOLUME/2);
    Mix_Chunk *sound_bullet;
    //Mix_Music *musique;
    //musique = Mix_LoadMUS("zelda_theme.wav");
    //Mix_VolumeMusic(MIX_MAX_VOLUME / 4);
    sound_bullet = Mix_LoadWAV("dspistol.wav");

    SDL_SetRenderDrawColor(pRenderer, 255, 255, 255, 255);

    //Mix_PlayMusic(musique, -1);

		while(isOpen){	// Tant que l'application est active

			while(SDL_PollEvent(&events)){	// Boucle de gestion des événements de la SDL

				switch(events.type){	// Détection des événements de la SDL

					case SDL_WINDOWEVENT: // Fermes l'application si clique de la souris sur la croix rouge de la fenêtre
							 if (events.window.event == SDL_WINDOWEVENT_CLOSE){
								 isOpen = SDL_FALSE;
								 break;
							 }


          /*Contenu Ajouté*/
          case SDL_MOUSEBUTTONUP: /* Clic de la souris */

              if (events.button.button == SDL_BUTTON_RIGHT){

                if (est_dedans(dst_tile11,events)){
                  selection_tile = 0;
                }
                else if (est_dedans(dst_tile22,events)){
                  selection_tile = 1;
                }

                fprintf(stdout,"Selection tile = %d\n", selection_tile);

                break;
              }

              if (events.button.button == SDL_BUTTON_LEFT){

                if (selection_tile == 0){
                  box = find_screen(screen,events);
                  screen[box].texture = initialiser_image("tile1.png",screen[box].rectangle.x,screen[box].rectangle.y,60,60,&screen[box].src,&(screen[box].dst),pRenderer);
                }
                else if (selection_tile == 1){
                  box = find_screen(screen,events);
                  screen[box].texture = initialiser_image("tile2.png",screen[box].rectangle.x,screen[box].rectangle.y,60,60,&screen[box].src,&(screen[box].dst),pRenderer);
                }

                break;
              }


              if (events.button.button == SDL_BUTTON_RIGHT){
                fprintf(stdout,"Tout de suite le clic droit du joueur Français\n");
                positionZozor.x = events.button.x;    /*RÉCUPÉRATION DES COORDONNÉES DU CLIC*/
                positionZozor.y = events.button.y;    /*RÉCUPÉRATION DES COORDONNÉES DU CLIC*/
                fprintf(stdout,"x = %d y= %d\n",positionZozor.x, positionZozor.y);
                break;
              }
              if (events.button.button == SDL_BUTTON_LEFT && est_dedans(dst1,events)==1 && bonjour_mario == 1){ /* On arrête le programme si on a fait un clic gauche */
                fprintf(stdout,"Mais où est Mario !\n");
                bonjour_mario = 0;
                fprintf(stdout,"Appuie avec le clic gauche\n");
                positionZozor.x = events.button.x;    /*RÉCUPÉRATION DES COORDONNÉES DU CLIC*/
                positionZozor.y = events.button.y;    /*RÉCUPÉRATION DES COORDONNÉES DU CLIC*/
                fprintf(stdout,"x = %d y= %d\n",positionZozor.x, positionZozor.y);
                break;
              }
              if (events.button.button == SDL_BUTTON_LEFT && bonjour_mario == 0){ /* On arrête le programme si on a fait un clic gauche */
                dst1.x = events.button.x - 75;
                dst1.y = events.button.y - 100;
                bonjour_mario = 1;
                fprintf(stdout,"Mais C'est comme Mario !\n");
                fprintf(stdout,"Appuie avec le clic gauche\n");
                positionZozor.x = events.button.x;    /*RÉCUPÉRATION DES COORDONNÉES DU CLIC*/
                positionZozor.y = events.button.y;    /*RÉCUPÉRATION DES COORDONNÉES DU CLIC*/
                fprintf(stdout,"x = %d y= %d\n",positionZozor.x, positionZozor.y);
                break;
              }

              if (events.button.button == SDL_BUTTON_MIDDLE){ /* On arrête le programme si on a fait un clic molette */
                fprintf(stdout,"Appui avec le clic molette\n");
                positionZozor.x = events.button.x;    /*RÉCUPÉRATION DES COORDONNÉES DU CLIC*/
                positionZozor.y = events.button.y;    /*RÉCUPÉRATION DES COORDONNÉES DU CLIC*/
                fprintf(stdout,"VERIF EN COURS \n");
                for(i=0;i<196;i++){
                  if(est_dedans(screen[i].rectangle,events)){
                    fprintf(stdout,"Case nb : %d de x : %d et y : %d \n", i, screen[i].rectangle.x, screen[i].rectangle.y);
                  }
                }
                fprintf(stdout,"x = %d y= %d\n",positionZozor.x, positionZozor.y);
                break;
              }
          case SDL_MOUSEMOTION:
            positionZozor.x = events.motion.x;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            positionZozor.y = events.motion.y;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            //fprintf(stdout,"x = %d y= %d\n",positionZozor.x, positionZozor.y);
            break;

          case SDL_KEYDOWN:
            if (events.key.keysym.sym == SDLK_z){
              key_up_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_s){
              key_down_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_q){
              key_left_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_d){
              key_right_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              shooting = true;
            }
            break;

          case SDL_KEYUP:
            if (events.key.keysym.sym == SDLK_z){
              key_up_pressed = false;
              look = 0;
              look_up = 1;
              animation = 0;
            }
            if (events.key.keysym.sym == SDLK_s){
              key_down_pressed = false;
              look = 1;
              look_up = 0;
              animation = 0;
            }
            if (events.key.keysym.sym == SDLK_q){
              key_left_pressed = false;
              look = 2;
              look_left = 1;
              animation = 0;
            }
            if (events.key.keysym.sym == SDLK_d){
              key_right_pressed = false;
              look = 3;
              look_left = 0;
              animation = 0;
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              shooting = false;
            }
            break;

				  }

			}

      SDL_RenderClear(pRenderer);	// Rempli la fenêtre

      afficher_image(pRenderer, pTextureImage_tile1, src_tile1, dst_tile11);
      afficher_image(pRenderer, pTextureImage_tile2, src_tile2, dst_tile22);


      for(i=0;i<196;i++){
        afficher_image(pRenderer, screen[i].texture, screen[i].src, screen[i].dst);
      }

        if (bullet_shot == true){
          for (int i = 0; i < 19 ; i++){
            SDL_Log("la bullet : %d est dans l'etat live_bullet : %d", i, live_bullet[i]);
            if (dst_bullet[i].y <= 10 || dst_bullet[i].y >= 830 || dst_bullet[i].x <= 10 || dst_bullet[i].x >= 830){
              live_bullet[i] = -1;
            }
            else if (dst_bullet[i].y > -10 && dir_bullet[i] == 0 && live_bullet[i] != -1){
              dst_bullet[i].y -= 1;
            }
            else if (dst_bullet[i].y < 850 && dir_bullet[i] == 1 && live_bullet[i] != -1){
              dst_bullet[i].y += 1;
            }
            else if (dst_bullet[i].x > -10 && dir_bullet[i] == 2 && live_bullet[i] != -1){
              dst_bullet[i].x -= 1;
            }
            else if (dst_bullet[i].x < 850 && dir_bullet[i] == 3 && live_bullet[i] != -1){
              dst_bullet[i].x += 1;
            }
          }
          if (nb_bullet == 19){
            nb_bullet = 0;
          }
        }

        if(shooting == false && animation_shoot !=0 || (animation_shoot == 0 && compteur_animation_shoot !=0)){
          if (animation_shoot <= 0 && compteur_animation_shoot >= 25){
            animation_shoot = 1;
            compteur_animation_shoot = 0;
          }
          else if (animation_shoot >= 1 && compteur_animation_shoot >= 25){
            animation_shoot = 0;
            compteur_animation_shoot = 0;
          }
          else {
            compteur_animation_shoot++;
          }
        }

        if(shooting == true && look == 0){
          key_down_pressed = key_left_pressed = key_right_pressed = key_up_pressed = false;
          if (animation_shoot == 0){
            if (compteur_animation_shoot <= 0 && live_bullet[nb_bullet] == -1){
              bullet_shot = true;
              dir_bullet[nb_bullet] = 0;
              live_bullet[nb_bullet] = 1;
              pTexture_bullet[nb_bullet] = initialiser_image("bullet_top.png",dst1.x+25,dst1.y-8,5,8,&src_bullet[nb_bullet],&dst_bullet[nb_bullet],pRenderer);
              Mix_PlayChannel(1, sound_bullet, 0);
              nb_bullet++;
            }
            pTextureImage = initialiser_image("doom_top_shooting.png",dst1.x,dst1.y,45,56,&src1,&dst1,pRenderer);
            compteur_animation_shoot++;
            if (compteur_animation_shoot >= 25){
              animation_shoot++;
              compteur_animation_shoot = 0;
            }
          }
          else if (animation_shoot == 1){
            pTextureImage = initialiser_image("link_idle_up.png",dst1.x,dst1.y,18,26,&src1,&dst1,pRenderer);
            compteur_animation_shoot++;
            if (compteur_animation_shoot >= 25){
              animation_shoot--;
              compteur_animation_shoot = 0;
            }
          }
        }
        else if(shooting == true && look == 1){
          key_down_pressed = key_left_pressed = key_right_pressed = key_up_pressed = false;
          if (animation_shoot == 0){
            if (compteur_animation_shoot <= 0 && live_bullet[nb_bullet] == -1){
              bullet_shot = true;
              dir_bullet[nb_bullet] = 1;
              live_bullet[nb_bullet] = 1;
              pTexture_bullet[nb_bullet] = initialiser_image("bullet_down.png",dst1.x+8,dst1.y+20,5,8,&src_bullet[nb_bullet],&dst_bullet[nb_bullet],pRenderer);
              Mix_PlayChannel(1, sound_bullet, 0);
              nb_bullet++;
            }
            pTextureImage = initialiser_image("doom_down_shooting.png",dst1.x,dst1.y,45,56,&src1,&dst1,pRenderer);
            compteur_animation_shoot++;
            if (compteur_animation_shoot >= 25){
              animation_shoot++;
              compteur_animation_shoot = 0;
            }
          }
          else if (animation_shoot == 1){
            pTextureImage = initialiser_image("link_idle_down.png",dst1.x,dst1.y,45,56,&src1,&dst1,pRenderer);
            compteur_animation_shoot++;
            if (compteur_animation_shoot >= 25){
              animation_shoot--;
              compteur_animation_shoot = 0;
            }
          }
        }
        else if (shooting == true && look == 2){
          key_down_pressed = key_left_pressed = key_right_pressed = key_up_pressed = false;
          if (animation_shoot == 0){
            if (compteur_animation_shoot <= 0 && live_bullet[nb_bullet] == -1){
              bullet_shot = true;
              dir_bullet[nb_bullet] = 2;
              live_bullet[nb_bullet] = 1;
              pTexture_bullet[nb_bullet] = initialiser_image("bullet_left.png",dst1.x-10,dst1.y+21,8,5,&src_bullet[nb_bullet],&dst_bullet[nb_bullet],pRenderer);
              Mix_PlayChannel(1, sound_bullet, 0);
              nb_bullet++;
            }
            pTextureImage = initialiser_image("doom_left_shooting.png",dst1.x,dst1.y,45,56,&src1,&dst1,pRenderer);
            compteur_animation_shoot++;
            if (compteur_animation_shoot >= 25){
              animation_shoot++;
              compteur_animation_shoot = 0;
            }
          }
          else if (animation_shoot == 1){
            pTextureImage = initialiser_image("link_idle_left.png",dst1.x,dst1.y,45,56,&src1,&dst1,pRenderer);
            compteur_animation_shoot++;
            if (compteur_animation_shoot >= 25){
              animation_shoot--;
              compteur_animation_shoot = 0;
            }
          }
        }
        else if(shooting == true && look == 3){
          key_down_pressed = key_left_pressed = key_right_pressed = key_up_pressed = false;
          if (animation_shoot == 0){
            if (compteur_animation_shoot <= 0 && live_bullet[nb_bullet] == -1){
              bullet_shot = true;
              dir_bullet[nb_bullet] = 3;
              live_bullet[nb_bullet] = 1;
              pTexture_bullet[nb_bullet] = initialiser_image("bullet_right.png",dst1.x+10,dst1.y+21,8,5,&src_bullet[nb_bullet],&dst_bullet[nb_bullet],pRenderer);
              Mix_PlayChannel(1, sound_bullet, 0);
              nb_bullet++;
            }
            pTextureImage = initialiser_image("doom_right_shooting.png",dst1.x,dst1.y,45,56,&src1,&dst1,pRenderer);
            compteur_animation_shoot++;
            if (compteur_animation_shoot >= 25){
              animation_shoot++;
              compteur_animation_shoot = 0;
            }
          }
          else if (animation_shoot == 1){
            pTextureImage = initialiser_image("link_idle_right.png",dst1.x,dst1.y,45,56,&src1,&dst1,pRenderer);
            compteur_animation_shoot++;
            if (compteur_animation_shoot >= 25){
              animation_shoot--;
              compteur_animation_shoot = 0;
            }
          }
        }


        else {
          if (key_up_pressed == true){
            if (dst1.y >= 0 ){
              dst1.y -= 1;
            }
            if (animation == 0){
              pTextureImage = initialiser_image("link_walking_up_1.png",dst1.x,dst1.y,18*1.5,24*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 1){
              pTextureImage = initialiser_image("link_walking_up_2.png",dst1.x,dst1.y,18*1.5,27*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 2){
              pTextureImage = initialiser_image("link_walking_up_3.png",dst1.x,dst1.y,18*1.5,25*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 3){
              pTextureImage = initialiser_image("link_idle_up.png",dst1.x,dst1.y,18*1.5,23*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 4){
              pTextureImage = initialiser_image("link_walking_up_4.png",dst1.x,dst1.y,18*1.5,24*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 5){
              pTextureImage = initialiser_image("link_walking_up_5.png",dst1.x,dst1.y,18*1.5,27*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 6){
              pTextureImage = initialiser_image("link_walking_up_6.png",dst1.x,dst1.y,18*1.5,25*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation = 0;
                compteur_animation = 0;
              }
            }
          }
        else if (key_down_pressed == true){
          if (dst1.y <= 840 - 56){
            dst1.y += 1;
          }
          if (animation == 0){
              pTextureImage = initialiser_image("link_walking_down_1.png",dst1.x,dst1.y,18*1.5,29*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 1){
              pTextureImage = initialiser_image("link_walking_down_2.png",dst1.x,dst1.y,18*1.5,28*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 2){
              pTextureImage = initialiser_image("link_walking_down_3.png",dst1.x,dst1.y,18*1.5,25*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 3){
              pTextureImage = initialiser_image("link_idle_down.png",dst1.x,dst1.y,18*1.5,26*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 4){
              pTextureImage = initialiser_image("link_walking_down_4.png",dst1.x,dst1.y,18*1.5,29*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 5){
              pTextureImage = initialiser_image("link_walking_down_5.png",dst1.x,dst1.y,18*1.5,28*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 6){
              pTextureImage = initialiser_image("link_walking_down_6.png",dst1.x,dst1.y,18*1.5,25*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation = 0;
                compteur_animation = 0;
              }
            }
        }
        else if (key_left_pressed == true){
          if (dst1.x >= 0 ){
            dst1.x -= 1;
          }
            if (animation == 0){
              pTextureImage = initialiser_image("link_walking_left_1.png",dst1.x,dst1.y,19*1.5,23*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 1){
              pTextureImage = initialiser_image("link_walking_left_2.png",dst1.x,dst1.y,23*1.5,22*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 2){
              pTextureImage = initialiser_image("link_walking_left_3.png",dst1.x,dst1.y,24*1.5,22*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 3){
              pTextureImage = initialiser_image("link_idle_left.png",dst1.x,dst1.y,19*1.5,23*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 4){
              pTextureImage = initialiser_image("link_walking_left_4.png",dst1.x,dst1.y,19*1.5,23*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 5){
              pTextureImage = initialiser_image("link_walking_left_5.png",dst1.x,dst1.y,23*1.5,22*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 6){
              pTextureImage = initialiser_image("link_walking_left_6.png",dst1.x,dst1.y,24*1.5,22*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation = 0;
                compteur_animation = 0;
              }
            }
        }
        else if (key_right_pressed == true){
          if (dst1.x <= 840 - 45){
            dst1.x += 1;
          }
            if (animation == 0){
              pTextureImage = initialiser_image("link_walking_right_1.png",dst1.x,dst1.y,19*1.5,23*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 1){
              pTextureImage = initialiser_image("link_walking_right_2.png",dst1.x,dst1.y,23*1.5,22*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 2){
              pTextureImage = initialiser_image("link_walking_right_3.png",dst1.x,dst1.y,24*1.5,22*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 3){
              pTextureImage = initialiser_image("link_idle_right.png",dst1.x,dst1.y,19*1.5,23*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 4){
              pTextureImage = initialiser_image("link_walking_right_4.png",dst1.x,dst1.y,19*1.5,23*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 5){
              pTextureImage = initialiser_image("link_walking_right_5.png",dst1.x,dst1.y,23*1.5,22*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation++;
                compteur_animation = 0;
              }
            }
            else if (animation == 6){
              pTextureImage = initialiser_image("link_walking_right_6.png",dst1.x,dst1.y,24*1.5,22*1.5,&src1,&dst1,pRenderer);
              compteur_animation++;
              if (compteur_animation == limite_compteur_animation){
                animation = 0;
                compteur_animation = 0;
              }
            }
        }

        else if (key_right_pressed == false && key_down_pressed == false && key_left_pressed == false && key_up_pressed == false && look == 0){
          pTextureImage = initialiser_image("link_idle_up.png",dst1.x,dst1.y,18*1.5,23*1.5,&src1,&dst1,pRenderer);
        }
        else if (key_right_pressed == false && key_down_pressed == false && key_left_pressed == false && key_up_pressed == false && look == 1){
          pTextureImage = initialiser_image("link_idle_down.png",dst1.x,dst1.y,18*1.5,26*1.5,&src1,&dst1,pRenderer);
        }
        else if (key_right_pressed == false && key_down_pressed == false && key_left_pressed == false && key_up_pressed == false && look == 2){
          pTextureImage = initialiser_image("link_idle_left.png",dst1.x,dst1.y,19*1.5,23*1.5,&src1,&dst1,pRenderer);
        }
        else if (key_right_pressed == false && key_down_pressed == false && key_left_pressed == false && key_up_pressed == false && look == 3){
          pTextureImage = initialiser_image("link_idle_right.png",dst1.x,dst1.y,19*1.5,23*1.5,&src1,&dst1,pRenderer);
        }

        }

      for(i=0;i<19;i++){
        if (live_bullet[i] != -1){
          afficher_image(pRenderer, pTexture_bullet[i], src_bullet[i], dst_bullet[i]);
        }
      }
      afficher_image(pRenderer, pTextureImage, src1, dst1);

			SDL_RenderPresent(pRenderer); // Met à jour la fenêtre

      /*
      if (shooting == true){
        SDL_Log("Shooting = true");
      }
      else {
        SDL_Log("Shooting = false");
      }
      if (bullet_shot == true){
        SDL_Log("bullet_shot = true");
      }
      else {
        SDL_Log("bullet_shot = false");
      }
      SDL_Log("Look = %d ... animation_shoot = %d ... compteur_animation_shoot = %d ...", look, animation_shoot,compteur_animation_shoot);
      */

      SDL_Delay(5);

		}

    Mix_FreeChunk(sound_bullet);
    //Mix_FreeMusic(musique);
    Mix_CloseAudio(); //Fermeture de l'API
		SDL_DestroyRenderer(pRenderer);
		SDL_DestroyWindow(pWindow);
    TTF_Quit();
    SDL_Quit(); // Arrêt de la SDL (libération de la mémoire).

    return 0;
}
