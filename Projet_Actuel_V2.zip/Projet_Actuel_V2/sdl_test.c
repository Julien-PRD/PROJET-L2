#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "fonction_basiques.h"

// http://sdz.tdct.org/sdz/faire-des-rotations-avec-sdl-gfx.html
// apprendre rotation

int main(int argc, char *argv[])
{
		if (SDL_Init(SDL_INIT_VIDEO) < 0){	// Initialisation de la SDL
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (SDL_Init(SDL_INIT_EVENTS) < 0){ // Initialisation des événements
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (TTF_Init() < 0){ // Initialisation de SDL_ttf
    	SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", TTF_GetError());
    	return EXIT_FAILURE;
		}
    //if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1){ //Initialisation de l'API Mixer
    //  printf("%s", Mix_GetError());
  //  }

    SDL_Window* pWindow;
		SDL_Renderer* pRenderer;
		SDL_Event events;
    SDL_Rect positionZozor; // Position de la souris

		if (SDL_CreateWindowAndRenderer(840, 840, SDL_WINDOW_SHOWN, &pWindow, &pRenderer) < 0)	// SDL_CreateWindowAndRenderer(taille_x, taille_x, window_settings, ptr_SDL_Window, ptr_SDL_Renderer)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        SDL_Quit();
        return EXIT_FAILURE;
    }

		const char* title;

		SDL_SetWindowTitle(pWindow, "SDL_Program");	// Nom de la fenêtre
		SDL_SetRenderDrawBlendMode(pRenderer, SDL_BLENDMODE_BLEND);

    load_image_t tab_load_image[NB_IMAGE];

    chargement_image(tab_load_image);

    player_t player = initialiser_joueur(player, pRenderer, tab_load_image);

		bool isOpen = true;
    int i;
		bool ramasser=false;

bool ramasser_open = false;
bool ramasser_open2 = false;
bool ramasser_open3 = false;


    //player.sprite = initialiser_image("link_idle_down.png",480,480,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
    //player.image = changement_image(player.image, "link_idle_down.png", 480, 480, 19*1.5, 23*1.5, pRenderer,tab_load_image);

 image_t map;
 image_t levier10;
 image_t levier20;
 image_t levier30;
 image_t lampe10;
 image_t lampe20;
 image_t lampe30;
 int xl1=150;
 int yl1=150;
 int xl2=650;
 int yl2=200;
 int xl3=150;
 int yl3=700;


 int xla1=400;
 int xla2=450;
 int xla3=500;
 int yla=400;





    SDL_Rect rect_map, src_map, dst_map;
    map.texture = initialiser_image_remastered(tab_load_image[57].surface,0,0,840,840,&src_map,&dst_map,pRenderer);

		levier10.texture = initialiser_image_remastered(tab_load_image[68].surface,xl1,yl1,32,24,&src_map,&dst_map,pRenderer);
		levier20.texture = initialiser_image_remastered(tab_load_image[68].surface,xl2,yl2,32,24,&src_map,&dst_map,pRenderer);
		levier30.texture = initialiser_image_remastered(tab_load_image[68].surface,xl3,yl3,32,24,&src_map,&dst_map,pRenderer);

		lampe10.texture = initialiser_image_remastered(tab_load_image[68].surface,xla1,yla,32,24,&src_map,&dst_map,pRenderer);
		lampe20.texture = initialiser_image_remastered(tab_load_image[68].surface,xla2,yla,32,24,&src_map,&dst_map,pRenderer);
		lampe30.texture = initialiser_image_remastered(tab_load_image[68].surface,xla3,yla,32,24,&src_map,&dst_map,pRenderer);

    SDL_Surface* couleur_image = IMG_Load("map_couleur.png");

    Mix_AllocateChannels(10);
    Mix_Volume(1,MIX_MAX_VOLUME/2);
    Mix_Chunk *sound_bullet;
		Mix_Chunk *sound_bow;
		Mix_Chunk *sound_arrow;
    Mix_Music *musique;
    musique = Mix_LoadMUS("zelda_theme.wav");
    Mix_VolumeMusic(MIX_MAX_VOLUME / 4);
    sound_bullet = Mix_LoadWAV("dspistol.wav");
		sound_bow = Mix_LoadWAV("bow_pull_sound.wav");
		sound_arrow = Mix_LoadWAV("arrow_sound.wav");
		Mix_Volume(3, MIX_MAX_VOLUME/4);
		int levier1=0;
			int levier2=0;
			int levier3=0;
			int lampe1=0;
			int lampe2=0;
			int lampe3=0;
			int rechargement=1;
		int hauteur_carte=0;
		int largeur_carte=0;
		int compteur_map1=0;
		int compteur_map2=0;
    SDL_SetRenderDrawColor(pRenderer, 255, 255, 255, 255);

    Mix_PlayMusic(musique, -1);

		while(isOpen){	// Tant que l'application est active

			while(SDL_PollEvent(&events)){	// Boucle de gestion des événements de la SDL

				switch(events.type){	// Détection des événements de la SDL

					case SDL_WINDOWEVENT: // Fermes l'application si clique de la souris sur la croix rouge de la fenêtre
							 if (events.window.event == SDL_WINDOWEVENT_CLOSE){
								 isOpen = SDL_FALSE;
								 break;
							 }

          case SDL_MOUSEMOTION:
            positionZozor.x = events.motion.x;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            positionZozor.y = events.motion.y;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            break;

          case SDL_KEYDOWN:
            if (events.key.keysym.sym == SDLK_z){
							//SDL_Log("postion y du perso %d",player.image.position_y);
						 player.input.key_up_pressed = true;
						 if(player.image.position_y<0){
							// SDL_Log("changement de carte");
							 rechargement=1;
							 hauteur_carte--;
							player.image.dst.y=815;

						 }
            }
            if (events.key.keysym.sym == SDLK_s){
//SDL_Log("postion y du perso %d",player.image.position_y);
              player.input.key_down_pressed = true;
							if(player.image.position_y>784){
							 //SDL_Log("changement de carte");
							 rechargement=1;
							 hauteur_carte++;
							 player.image.dst.y=1;


						 }
            }
            if (events.key.keysym.sym == SDLK_q){
						//	SDL_Log("postion x du perso %d",player.image.position_x);
              player.input.key_left_pressed = true;
							if(player.image.position_x<2){
					//	SDL_Log("changement de carte");
						rechargement=1;
						largeur_carte--;
						player.image.dst.x=795;


					}
            }
            if (events.key.keysym.sym == SDLK_d){
						//	SDL_Log("postion x du perso %d",player.image.position_x);
						player.input.key_right_pressed = true;
						if(player.image.position_x>785){
					//	 SDL_Log("changement de carte");
						 rechargement=1;
						 largeur_carte++;
						 player.image.dst.x=5;



					 }
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              player.input.key_space_pressed = true;
            }
						if (events.key.keysym.sym == SDLK_LSHIFT){
              player.input.key_shift_pressed = true;
            }
            break;

          case SDL_KEYUP:
            if (events.key.keysym.sym == SDLK_z){
              player.input.key_up_pressed = false;
              player.look = 0;
              player.look_up = 1;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_s){
              player.input.key_down_pressed = false;
              player.look = 1;
              player.look_up = 0;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_q){
              player.input.key_left_pressed = false;
              player.look = 2;
              player.look_left = 1;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_d){
              player.input.key_right_pressed = false;
              player.look = 3;
              player.look_left = 0;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              player.input.key_space_pressed = false;
            }
						if (events.key.keysym.sym == SDLK_LSHIFT){
              player.input.key_shift_pressed = false;
            }
				  }

if(events.key.keysym.sym == SDLK_e ){//&& input.key_down_pressed == false && input.key_left_pressed == false && input.key_right_pressed == false && input.key_up_pressed == false){
									if(player.look == 0 && player.image.dst.x >= xl1-10 && player.image.dst.x <= xl1+40 && player.image.dst.y <= yl1+40 && player.image.dst.y>= yl1-10 ){
										ramasser = true;
										SDL_Log("rammmm");
										if(levier1==0){
											levier1=1;
										}
										else{
											levier1=0;
										}
										SDL_Log("levier1 = %d",levier1);



								//		pTextureImage_link1 = i:nitialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
									//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
									}

									else if(player.look == 1 && player.image.dst.x >= xl1-30 && player.image.dst.x <= xl1+40 && player.image.dst.y <= yl1 && player.image.dst.y >=yl1-70){
										ramasser = true;
										SDL_Log("rammmm");
										if(levier1==0){
											levier1=1;
										}
										else{
											levier1=0;
										}
										SDL_Log("levier = %d",levier1);

									//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
									//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
									}

									else if(player.look == 2 && player.image.dst.x <= xl1+45 && player.image.dst.x >= xl1-15 && player.image.dst.y <= yl1+20 && player.image.dst.y >= yl1-10){
										ramasser = true;
										SDL_Log("rammmm");
										if(levier1==0){
											levier1=1;
										}
										else{
											levier1=0;
										}
										SDL_Log("levier = %d",levier1);

									//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
									//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
									}

									else if(player.look == 3  && player.image.dst.x <= xl1+30 && player.image.dst.x >= xl1-50 && player.image.dst.y <= yl1+20 && player.image.dst.y >= yl1-10){
										ramasser = true;
										SDL_Log("rammmm");
										if(levier1==0){
											levier1=1;
										}
										else{
											levier1=0;
										}
										SDL_Log("levier = %d",levier1);

									//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
										//case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
									}


						if(player.look == 0 && player.image.dst.x >= xl2-10 && player.image.dst.x <= xl2+40 && player.image.dst.y <= yl2+40 && player.image.dst.y >= yl2-10 ){
							ramasser = true;
							SDL_Log("rammmm");


							if(levier2==0){
								levier2=1;
							}
							else{
								levier2=0;
							}
							SDL_Log("levier = %d",levier2);

						//		pTextureImage_link1 = i:nitialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
						//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
						}

						else if(player.look == 1 && player.image.dst.x >= xl2-30 && player.image.dst.x <= xl2+40 && player.image.dst.y <= yl2 && player.image.dst.y >=yl2-70){
							ramasser = true;
							SDL_Log("rammmm");
							if(levier2==0){
								levier2=1;
							}
							else{
								levier2=0;
							}
							SDL_Log("levier = %d",levier2);

						//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
						//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
						}

						else if(player.look == 2 && player.image.dst.x <= xl2+45 && player.image.dst.x >= xl2-15 && player.image.dst.y <= yl2+20 && player.image.dst.y >= yl2-10){
							ramasser = true;
							SDL_Log("rammmm");
							if(levier2==0){
								levier2=1;
							}
							else{
								levier2=0;
							}
							SDL_Log("levier = %d",levier2);

						//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
						//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
						}

						else if(player.look == 3  && player.image.dst.x <= xl2+30 && player.image.dst.x >= xl2-50 && player.image.dst.y <= yl2+20 && player.image.dst.y >= yl2-10){
							ramasser = true;
							SDL_Log("rammmm");
							if(levier2==0){
								levier2=1;
							}
							else{
								levier2=0;
							}
							SDL_Log("levier = %d",levier2);

						//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
							//case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
						}




						if(player.look == 0 && player.image.dst.x >= xl3-10 && player.image.dst.x <= xl3+40 && player.image.dst.y <= yl3+40 && player.image.dst.y >= yl3-10 ){
							ramasser = true;
							SDL_Log("rammmm");


							if(levier3==0){
								levier3=1;
							}
							else{
								levier3=0;
							}
							SDL_Log("levier = %d",levier3);

						//		pTextureImage_link1 = i:nitialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
						//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
						}

						else if(player.look == 1 && player.image.dst.x >= xl3-30 && player.image.dst.x <= xl3+40 && player.image.dst.y <= yl3 && player.image.dst.y >=yl3-70){
							ramasser = true;
							SDL_Log("rammmm");
							if(levier3==0){
								levier3=1;
							}
							else{
								levier3=0;
							}
							SDL_Log("levier = %d",levier3);

						//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
						//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
						}

						else if(player.look == 2 && player.image.dst.x <= xl3+45 && player.image.dst.x >= xl3-15 && player.image.dst.y <= yl3+20 && player.image.dst.y >= yl3-10){
							ramasser = true;
							SDL_Log("rammmm");
							if(levier3==0){
								levier3=1;
							}
							else{
								levier3=0;
							}
							SDL_Log("levier = %d",levier3);

						//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
						//	case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
						}

						else if(player.look == 3  && player.image.dst.x <= xl3+30 && player.image.dst.x >= xl3-50 && player.image.dst.y <= yl3+20 && player.image.dst.y >= yl3-10){
							ramasser = true;
							SDL_Log("rammmm");
							if(levier3==0){
								levier3=1;
							}
							else{
								levier3=0;
							}
							SDL_Log("levier = %d",levier3);

						//	pTextureImage_link1 = initialiser_image("link_idle_right.png", 1000,1000,40,40,&src_link1,&dst_link1,pRenderer);
							//case1.texture = initialiser_image("link_idle_right.png", case1.rectangle.x,case1.rectangle.y,case1.rectangle.h,case1.rectangle.w,&case1.src,&case1.dst,pRenderer);
						}
					}
					break;

			}

      SDL_RenderClear(pRenderer);
if(rechargement==1){

			if(hauteur_carte ==0 && largeur_carte==0){

							 map= changement_image (map, "map.png", 0, 0, 840, 840, pRenderer, tab_load_image);
							 couleur_image = IMG_Load("map_couleur.png");




 	 								}


 	 						 if(hauteur_carte ==1 && largeur_carte==0){
					 		 	map=changement_image (map, "carte1.png", 0, 0, 840, 840, pRenderer, tab_load_image);
					 			couleur_image = IMG_Load("carte2_hitbox.png");

 	 						 }

 	 						 if(hauteur_carte ==0 && largeur_carte==1){
							 map= changement_image (map, "carte3.png", 0, 0, 840, 840, pRenderer, tab_load_image);
							 couleur_image = IMG_Load("carte4_hitbox.png");


 	 						 }
 	 						 if(hauteur_carte ==1 && largeur_carte==1){
							 map= changement_image (map, "carte2.png", 0, 0, 840, 840, pRenderer, tab_load_image);

							 couleur_image = IMG_Load("carte3_hitbox.png");

 	 						 }
 	 						 if(hauteur_carte ==0 && largeur_carte==2){
								 map= changement_image (map, "carte4.png", 0, 0, 840, 840, pRenderer, tab_load_image);

								 couleur_image = IMG_Load("carte5_hitbox.png");

 	 						 }

 							 if(hauteur_carte ==1 && largeur_carte==2){

					 map= changement_image (map, "carte5.png", 0, 0, 840, 840, pRenderer, tab_load_image);
					 couleur_image = IMG_Load("carte6_hitbox.png");


					 lampe10=changement_image (lampe10, "fleur.png", xl1, yl1, 32, 24, pRenderer, tab_load_image);
 					lampe20=changement_image (lampe20, "fleur.png", xl2, yl2, 32, 24, pRenderer, tab_load_image);
 					lampe30=changement_image (lampe30, "fleur.png", xl3, yl3, 32, 24, pRenderer, tab_load_image);

						afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
						afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
						afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);
					  }














rechargement=0;
}
// on affiche tout
afficher_image(pRenderer, map.texture, map.src, map.dst);





if(hauteur_carte ==1 && largeur_carte==2){












if(levier1==0){
levier10=changement_image (levier10, "arbust.png", xl1, yl1, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, levier10.texture, levier10.src, levier10.dst);
}
else{
 levier10=changement_image (levier10, "fleur.png", xl1, yl1, 32, 24, pRenderer, tab_load_image);
 afficher_image(pRenderer, levier10.texture, levier10.src, levier10.dst);

}




if(levier2==0){
	levier20=changement_image (levier20, "arbust.png", xl2, yl2, 32, 24, pRenderer, tab_load_image);
	afficher_image(pRenderer, levier20.texture, levier20.src, levier20.dst);

}
else{
	levier20=changement_image (levier20, "fleur.png", xl2, yl2, 32, 24, pRenderer, tab_load_image);
	afficher_image(pRenderer, levier20.texture, levier20.src, levier20.dst);

}



if(levier3==0){
	levier30=changement_image (levier30, "arbust.png", xl3, yl3, 32, 24, pRenderer, tab_load_image);
	afficher_image(pRenderer, levier30.texture, levier30.src, levier30.dst);

}
else{
	levier30=changement_image (levier30, "fleur.png", xl3, yl3, 32, 24, pRenderer, tab_load_image);
	afficher_image(pRenderer, levier30.texture, levier30.src, levier30.dst);

}








if(levier1==0 && levier2==0 && levier3==0){//reponse
	lampe10=changement_image (lampe10, "arbust.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "arbust.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "arbust.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);


}

if(levier1==0 && levier2==0 && levier3==1){//reponse
	lampe10=changement_image (lampe10, "arbust.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "arbust.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "fleur.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);


}
if(levier1==0 && levier2==1 && levier3==0){//reponse
	lampe10=changement_image (lampe10, "arbust.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "fleur.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "arbust.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);

}
if(levier1==1 && levier2==0 && levier3==0){//reponse
	lampe10=changement_image (lampe10, "fleur.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "arbust.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "arbust.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);

}
if(levier1==0 && levier2==1 && levier3==1){//reponse
	lampe10=changement_image (lampe10, "arbust.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "fleur.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "fleur.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);

}


if(levier1==1 && levier2==1 && levier3==0){//reponse
	lampe10=changement_image (lampe10, "fleur.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "fleur.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "arbust.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);


}


if(levier1==1 && levier2==0 && levier3==1){//reponse
lampe10=changement_image (lampe10, "fleur.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
lampe20=changement_image (lampe20, "fleur.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
lampe30=changement_image (lampe30, "fleur.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
SDL_Log("ffesfsef");
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);

}



if(levier1==1 && levier2==1 && levier3==1){//reponse
	lampe10=changement_image (lampe10, "arbust.png", xla1, yla, 32, 24, pRenderer, tab_load_image);
	lampe20=changement_image (lampe20, "arbust.png", xla2, yla, 32, 24, pRenderer, tab_load_image);
	lampe30=changement_image (lampe30, "arbust.png", xla3, yla, 32, 24, pRenderer, tab_load_image);
afficher_image(pRenderer, lampe10.texture, lampe10.src, lampe10.dst);
afficher_image(pRenderer, lampe20.texture, lampe20.src, lampe20.dst);
afficher_image(pRenderer, lampe30.texture, lampe30.src, lampe30.dst);


}


afficher_image(pRenderer, levier10.texture, levier10.src, levier10.dst);
afficher_image(pRenderer, levier20.texture, levier20.src, levier20.dst);
afficher_image(pRenderer, levier30.texture, levier30.src, levier30.dst);


}



























      	player = update_arrow(player);
				player = check_and_reset_animation(player);
				if (player.input.key_space_pressed == true) {
					player = player_shooting_bow(player, sound_bow, sound_arrow, pRenderer, tab_load_image);
				}
				else{
					if (player.input.key_shift_pressed == true){
						player.speed = 2;
						player.limite_compteur_animation = 20;
					}
					else{
						player.speed = 1;
						player.limite_compteur_animation = 25;
					}
					player = player_moving(player, pRenderer, couleur_image, tab_load_image);
				}

      for(i=0;i<19;i++){
        if (player.live_bullet[i] != -1){
          afficher_image(pRenderer, player.pTexture_bullet[i], player.src_bullet[i], player.dst_bullet[i]);
        }
      }

      afficher_image(pRenderer, player.image.texture, player.image.src, player.image.dst);

			SDL_RenderPresent(pRenderer); // Met à jour la fenêtre

      SDL_Delay(5);

		}



    detruire_image(tab_load_image);
    SDL_FreeSurface(couleur_image);
   Mix_FreeChunk(sound_bullet);
		Mix_FreeChunk(sound_arrow);
		Mix_FreeChunk(sound_bow);
   Mix_FreeMusic(musique);
    Mix_CloseAudio(); //Fermeture de l'API
		SDL_DestroyRenderer(pRenderer);
		SDL_DestroyWindow(pWindow);
    TTF_Quit();
    SDL_Quit(); // Arrêt de la SDL (libération de la mémoire).

    return 0;

}
