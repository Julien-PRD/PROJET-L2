#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "fonction_basiques.h"

int main(int argc, char *argv[])
{
		if (SDL_Init(SDL_INIT_VIDEO) < 0){	// Initialisation de la SDL
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (SDL_Init(SDL_INIT_EVENTS) < 0){ // Initialisation des événements
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (TTF_Init() < 0){ // Initialisation de SDL_ttf
    	SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", TTF_GetError());
    	return EXIT_FAILURE;
		}
    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1){ //Initialisation de l'API Mixer
      printf("%s", Mix_GetError());
    }

    SDL_Window* pWindow;
		SDL_Renderer* pRenderer;
		SDL_Event events;
    SDL_Rect positionZozor; // Position de la souris

    player_t player;
    player.bullet_shot = false;
    player.idle = true;
    player.look_down = 1;
    player.look_left = player.look_right = player.look_up = 0;
    player.changement_frame = player.animation = player.animation_shoot = player.old_animation = player.compteur_animation = player.compteur_animation_shoot = 0;
    player.limite_compteur_animation = 25;
    player.limite_compteur_animation_shoot = 20;
    player.speed = 0.6;
    player.look = 1;

    input_t input;
    input.key_up_pressed = input.key_down_pressed = input.key_left_pressed = input.key_right_pressed = input.key_space_pressed = false;

		bool isOpen = true;
    bool key_up_pressed = false;
    bool key_down_pressed = false;
    bool key_left_pressed = false;
    bool key_right_pressed = false;
    bool shooting = false;
    bool bullet_shot = false;
    bool idle = true;
		const char* title;

    int i = 0;
/*
    int look_down = 1;
    int look_up = 0;
    int look_left = 0;
    int look_right = 0;
    int changement_frame = 0;
    int speed = 0.6;
    int look = 1; // up = 0 , down = 1 , left = 2 , right = 3
    int player.animation = 0;
    int animation_shoot = 0;
    int old_animation = 0;
    int player.compteur_animation = 0;
    int compteur_animation_shoot = 0;
    const int player.limite_compteur_animation = 25;
*/
    case_t screen[196];
    remplir_screen(screen);

    initialiser_white_screen(screen, pRenderer);

		if (SDL_CreateWindowAndRenderer(840, 840, SDL_WINDOW_SHOWN, &pWindow, &pRenderer) < 0)	// SDL_CreateWindowAndRenderer(taille_x, taille_x, window_settings, ptr_SDL_Window, ptr_SDL_Renderer)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        SDL_Quit();
        return EXIT_FAILURE;
    }

		SDL_SetWindowTitle(pWindow, "SDL_Program");	// Nom de la fenêtre
		SDL_SetRenderDrawBlendMode(pRenderer, SDL_BLENDMODE_BLEND);

    SDL_Rect src1,dst1;
    player.sprite = initialiser_image("doom_down.png",480,480,45,56,&player.src,&player.dst,pRenderer);
    SDL_Rect src_tile1,dst_tile11;
    SDL_Texture* pTextureImage_tile1 = initialiser_image("tile1.png",0,0,60,60,&src_tile1,&dst_tile11,pRenderer);
    SDL_Rect src_tile2,dst_tile22;
    SDL_Texture* pTextureImage_tile2 = initialiser_image("tile2.png",0,60,60,60,&src_tile2,&dst_tile22,pRenderer);

    SDL_Rect src_bullet1,dst_bullet1;
    SDL_Texture* pTextureImage_bullet;

    SDL_Texture *pTexture_bullet[20];
    SDL_Rect dst_bullet[20];
    int dir_bullet[20];
    SDL_Rect src_bullet[20];
    for (int i = 0; i<19 ;i++){
      src_bullet[i].x = src_bullet[i].y = src_bullet[i].h = src_bullet[i].w = 0;
    }
    int live_bullet[20] = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
    int nb_bullet = 0;

    SDL_Texture *pTexture_tile1[500];
    SDL_Rect dst_tile1[500];
    int nb_pTexture_tile1 = 0;

    SDL_Texture *pTexture_tile2[500];
    SDL_Rect dst_tile2[500];
    int nb_pTexture_tile2 = 0;

    Mix_AllocateChannels(10);
    Mix_Volume(1,MIX_MAX_VOLUME/2);
    Mix_Chunk *sound_bullet;
    Mix_Music *musique;
    musique = Mix_LoadMUS("zelda_theme.wav");
    Mix_VolumeMusic(MIX_MAX_VOLUME / 4);
    sound_bullet = Mix_LoadWAV("dspistol.wav");

    SDL_SetRenderDrawColor(pRenderer, 255, 255, 255, 255);

    Mix_PlayMusic(musique, -1);

		while(isOpen){	// Tant que l'application est active

			while(SDL_PollEvent(&events)){	// Boucle de gestion des événements de la SDL

				switch(events.type){	// Détection des événements de la SDL

					case SDL_WINDOWEVENT: // Fermes l'application si clique de la souris sur la croix rouge de la fenêtre
							 if (events.window.event == SDL_WINDOWEVENT_CLOSE){
								 isOpen = SDL_FALSE;
								 break;
							 }

          case SDL_MOUSEMOTION:
            positionZozor.x = events.motion.x;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            positionZozor.y = events.motion.y;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            break;

          case SDL_KEYDOWN:
            if (events.key.keysym.sym == SDLK_z){
              input.key_up_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_s){
              input.key_down_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_q){
              input.key_left_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_d){
              input.key_right_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              input.key_space_pressed = true;
              shooting = true;
            }
            break;

          case SDL_KEYUP:
            if (events.key.keysym.sym == SDLK_z){
              input.key_up_pressed = false;
              player.look = 0;
              player.look_up = 1;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_s){
              input.key_down_pressed = false;
              player.look = 1;
              player.look_up = 0;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_q){
              input.key_left_pressed = false;
              player.look = 2;
              player.look_left = 1;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_d){
              input.key_right_pressed = false;
              player.look = 3;
              player.look_left = 0;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              input.key_space_pressed = false;
            }
            break;

				  }

			}

      SDL_RenderClear(pRenderer);	// Rempli la fenêtre
      afficher_image(pRenderer, pTextureImage_tile1, src_tile1, dst_tile11);
      afficher_image(pRenderer, pTextureImage_tile2, src_tile2, dst_tile22);


      for(i=0;i<196;i++){
        afficher_image(pRenderer, screen[i].texture, screen[i].src, screen[i].dst);
      }

        if (player.bullet_shot == true){
          for (int i = 0; i < 19 ; i++){
            SDL_Log("la bullet : %d est dans l'etat live_bullet : %d", i, live_bullet[i]);
            if (dst_bullet[i].y <= 10 || dst_bullet[i].y >= 830 || dst_bullet[i].x <= 10 || dst_bullet[i].x >= 830){
              live_bullet[i] = -1;
            }
            else if (dst_bullet[i].y > -10 && dir_bullet[i] == 0 && live_bullet[i] != -1){
              dst_bullet[i].y -= 1;
            }
            else if (dst_bullet[i].y < 850 && dir_bullet[i] == 1 && live_bullet[i] != -1){
              dst_bullet[i].y += 1;
            }
            else if (dst_bullet[i].x > -10 && dir_bullet[i] == 2 && live_bullet[i] != -1){
              dst_bullet[i].x -= 1;
            }
            else if (dst_bullet[i].x < 850 && dir_bullet[i] == 3 && live_bullet[i] != -1){
              dst_bullet[i].x += 1;
            }
          }
          if (nb_bullet == 19){
            nb_bullet = 0;
          }
        }

        if(input.key_space_pressed == false && player.animation_shoot !=0 || (player.animation_shoot == 0 && player.compteur_animation_shoot !=0)){
          if (player.animation_shoot <= 0 && player.compteur_animation_shoot >= 25){
            player.animation_shoot = 1;
            player.compteur_animation_shoot = 0;
          }
          else if (player.animation_shoot >= 1 && player.compteur_animation_shoot >= 25){
            player.animation_shoot = 0;
            player.compteur_animation_shoot = 0;
          }
          else {
            player.compteur_animation_shoot++;
          }
        }

        if(input.key_space_pressed == true && player.look == 0){
          input.key_down_pressed = input.key_left_pressed = input.key_right_pressed = input.key_up_pressed = false;
          if (player.animation_shoot == 0){
            player.sprite = initialiser_image("link_shooting_up_1.png",player.dst.x,player.dst.y,21*1.5,28*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 1){
            player.sprite = initialiser_image("link_shooting_up_2.png",player.dst.x,player.dst.y,22*1.5,27*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 2){
            player.sprite = initialiser_image("link_shooting_up_3.png",player.dst.x,player.dst.y,22*1.5,27*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 3){
            player.sprite = initialiser_image("link_shooting_up_4.png",player.dst.x,player.dst.y,24*1.5,27*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 4){
            if (player.compteur_animation_shoot <= 0 && live_bullet[nb_bullet] == -1){
              player.bullet_shot = true;
              dir_bullet[nb_bullet] = 0;
              live_bullet[nb_bullet] = 1;
              pTexture_bullet[nb_bullet] = initialiser_image("arrow_up.png",player.dst.x+10,player.dst.y+13,5*1.5,15*1.5,&src_bullet[nb_bullet],&dst_bullet[nb_bullet],pRenderer);
              Mix_PlayChannel(1, sound_bullet, 0);
              nb_bullet++;
            }
            player.sprite = initialiser_image("link_shooting_up_5.png",player.dst.x,player.dst.y,21*1.5,26*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 5){
            player.sprite = initialiser_image("link_shooting_up_6.png",player.dst.x,player.dst.y,21*1.5,24*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 6){
            player.sprite = initialiser_image("link_idle_up.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot = 0;
              player.compteur_animation_shoot = 0;
            }
          }
        }
        else if(input.key_space_pressed == true && player.look == 1){
          input.key_down_pressed = input.key_left_pressed = input.key_right_pressed = input.key_up_pressed = false;
          if (player.animation_shoot == 0){
            player.sprite = initialiser_image("link_shooting_down_1.png",player.dst.x,player.dst.y,21*1.5,28*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 1){
            player.sprite = initialiser_image("link_shooting_down_2.png",player.dst.x,player.dst.y,22*1.5,27*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 2){
            player.sprite = initialiser_image("link_shooting_down_3.png",player.dst.x,player.dst.y,22*1.5,27*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 3){
            player.sprite = initialiser_image("link_shooting_down_4.png",player.dst.x,player.dst.y,24*1.5,27*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 4){
            if (player.compteur_animation_shoot <= 0 && live_bullet[nb_bullet] == -1){
              player.bullet_shot = true;
              dir_bullet[nb_bullet] = 1;
              live_bullet[nb_bullet] = 1;
              pTexture_bullet[nb_bullet] = initialiser_image("arrow_down.png",player.dst.x+16,player.dst.y+13,5*1.5,15*1.5,&src_bullet[nb_bullet],&dst_bullet[nb_bullet],pRenderer);
              Mix_PlayChannel(1, sound_bullet, 0);
              nb_bullet++;
            }
            player.sprite = initialiser_image("link_shooting_down_5.png",player.dst.x,player.dst.y,21*1.5,26*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 5){
            player.sprite = initialiser_image("link_shooting_down_6.png",player.dst.x,player.dst.y,21*1.5,24*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 6){
            player.sprite = initialiser_image("link_idle_down.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot = 0;
              player.compteur_animation_shoot = 0;
            }
          }
        }
        else if (input.key_space_pressed == true && player.look == 2){
          input.key_down_pressed = input.key_left_pressed = input.key_right_pressed = input.key_up_pressed = false;
          if (player.animation_shoot == 0){
            player.sprite = initialiser_image("link_shooting_left_1.png",player.dst.x,player.dst.y,24*1.5,25*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 1){
            player.sprite = initialiser_image("link_shooting_left_2.png",player.dst.x,player.dst.y,27*1.5,25*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 2){
            player.sprite = initialiser_image("link_shooting_left_3.png",player.dst.x,player.dst.y,24*1.5,25*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 3){
            player.sprite = initialiser_image("link_shooting_left_4.png",player.dst.x,player.dst.y,28*1.5,24*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 4){
            if (player.compteur_animation_shoot <= 0 && live_bullet[nb_bullet] == -1){
              player.bullet_shot = true;
              dir_bullet[nb_bullet] = 2;
              live_bullet[nb_bullet] = 1;
              pTexture_bullet[nb_bullet] = initialiser_image("arrow_left.png",player.dst.x-10,player.dst.y+19,15*1.5,5*1.5,&src_bullet[nb_bullet],&dst_bullet[nb_bullet],pRenderer);
              Mix_PlayChannel(1, sound_bullet, 0);
              nb_bullet++;
            }
            player.sprite = initialiser_image("link_shooting_left_5.png",player.dst.x,player.dst.y,23*1.5,25*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 5){
            player.sprite = initialiser_image("link_shooting_left_6.png",player.dst.x,player.dst.y,21*1.5,25*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 6){
            player.sprite = initialiser_image("link_idle_left.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot = 0;
              player.compteur_animation_shoot = 0;
            }
          }
        }
        else if(input.key_space_pressed == true && player.look == 3){
          input.key_down_pressed = input.key_left_pressed = input.key_right_pressed = input.key_up_pressed = false;
          if (player.animation_shoot == 0){
            // J AVAIS CHANGE ICI
            player.sprite = initialiser_image("link_shooting_right_1.png",player.dst.x-3,player.dst.y,24*1.5,25*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 1){
            player.sprite = initialiser_image("link_shooting_right_2.png",player.dst.x-3,player.dst.y,27*1.5,25*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 2){
            player.sprite = initialiser_image("link_shooting_right_3.png",player.dst.x-3,player.dst.y,24*1.5,25*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 3){
            player.sprite = initialiser_image("link_shooting_right_4.png",player.dst.x-3,player.dst.y,28*1.5,24*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 4){
            if (player.compteur_animation_shoot <= 0 && live_bullet[nb_bullet] == -1){
              player.bullet_shot = true;
              dir_bullet[nb_bullet] = 3;
              live_bullet[nb_bullet] = 1;
              pTexture_bullet[nb_bullet] = initialiser_image("arrow_right.png",player.dst.x+10,player.dst.y+19,15*1.5,5*1.5,&src_bullet[nb_bullet],&dst_bullet[nb_bullet],pRenderer);
              Mix_PlayChannel(1, sound_bullet, 0);
              nb_bullet++;
            }
            player.sprite = initialiser_image("link_shooting_right_5.png",player.dst.x-3,player.dst.y,23*1.5,25*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 5){
            player.sprite = initialiser_image("link_shooting_right_6.png",player.dst.x-3,player.dst.y,21*1.5,25*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot++;
              player.compteur_animation_shoot = 0;
            }
          }
          else if (player.animation_shoot == 6){
            player.sprite = initialiser_image("link_idle_right.png",player.dst.x-3,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
            player.compteur_animation_shoot++;
            if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
              player.animation_shoot = 0;
              player.compteur_animation_shoot = 0;
            }
          }
        }
        else {
          if (input.key_up_pressed == true){
            if (player.dst.y >= 0 ){
              player.dst.y -= 1;
            }
            if (player.animation == 0){
              player.sprite = initialiser_image("link_walking_up_1.png",player.dst.x,player.dst.y,18*1.5,24*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 1){
              player.sprite = initialiser_image("link_walking_up_2.png",player.dst.x,player.dst.y,18*1.5,27*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 2){
              player.sprite = initialiser_image("link_walking_up_3.png",player.dst.x,player.dst.y,18*1.5,25*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 3){
              player.sprite = initialiser_image("link_idle_up.png",player.dst.x,player.dst.y,18*1.5,23*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 4){
              player.sprite = initialiser_image("link_walking_up_4.png",player.dst.x,player.dst.y,18*1.5,24*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 5){
              player.sprite = initialiser_image("link_walking_up_5.png",player.dst.x,player.dst.y,18*1.5,27*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 6){
              player.sprite = initialiser_image("link_walking_up_6.png",player.dst.x,player.dst.y,18*1.5,25*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation = 0;
                player.compteur_animation = 0;
              }
            }
          }
        else if (input.key_down_pressed == true){
          if (player.dst.y <= 840 - 56){
            player.dst.y += 1;
          }
          if (player.animation == 0){
              player.sprite = initialiser_image("link_walking_down_1.png",player.dst.x,player.dst.y,18*1.5,29*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 1){
              player.sprite = initialiser_image("link_walking_down_2.png",player.dst.x,player.dst.y,18*1.5,28*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 2){
              player.sprite = initialiser_image("link_walking_down_3.png",player.dst.x,player.dst.y,18*1.5,25*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 3){
              player.sprite = initialiser_image("link_idle_down.png",player.dst.x,player.dst.y,18*1.5,26*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 4){
              player.sprite = initialiser_image("link_walking_down_4.png",player.dst.x,player.dst.y,18*1.5,29*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 5){
              player.sprite = initialiser_image("link_walking_down_5.png",player.dst.x,player.dst.y,18*1.5,28*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 6){
              player.sprite = initialiser_image("link_walking_down_6.png",player.dst.x,player.dst.y,18*1.5,25*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation = 0;
                player.compteur_animation = 0;
              }
            }
        }
        else if (input.key_left_pressed == true){
          if (player.dst.x >= 0 ){
            player.dst.x -= 1;
          }
            if (player.animation == 0){
              player.sprite = initialiser_image("link_walking_left_1.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 1){
              player.sprite = initialiser_image("link_walking_left_2.png",player.dst.x,player.dst.y,23*1.5,22*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 2){
              player.sprite = initialiser_image("link_walking_left_3.png",player.dst.x,player.dst.y,24*1.5,22*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 3){
              player.sprite = initialiser_image("link_idle_left.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 4){
              player.sprite = initialiser_image("link_walking_left_4.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 5){
              player.sprite = initialiser_image("link_walking_left_5.png",player.dst.x,player.dst.y,23*1.5,22*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 6){
              player.sprite = initialiser_image("link_walking_left_6.png",player.dst.x,player.dst.y,24*1.5,22*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation = 0;
                player.compteur_animation = 0;
              }
            }
        }
        else if (input.key_right_pressed == true){
          if (player.dst.x <= 840 - 45){
            player.dst.x += 1;
          }
            if (player.animation == 0){
              player.sprite = initialiser_image("link_walking_right_1.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 1){
              player.sprite = initialiser_image("link_walking_right_2.png",player.dst.x,player.dst.y,23*1.5,22*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 2){
              player.sprite = initialiser_image("link_walking_right_3.png",player.dst.x,player.dst.y,24*1.5,22*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 3){
              player.sprite = initialiser_image("link_idle_right.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 4){
              player.sprite = initialiser_image("link_walking_right_4.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 5){
              player.sprite = initialiser_image("link_walking_right_5.png",player.dst.x,player.dst.y,23*1.5,22*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation++;
                player.compteur_animation = 0;
              }
            }
            else if (player.animation == 6){
              player.sprite = initialiser_image("link_walking_right_6.png",player.dst.x,player.dst.y,24*1.5,22*1.5,&player.src,&player.dst,pRenderer);
              player.compteur_animation++;
              if (player.compteur_animation == player.limite_compteur_animation){
                player.animation = 0;
                player.compteur_animation = 0;
              }
            }
        }

        else if (input.key_right_pressed == false && input.key_down_pressed == false && input.key_left_pressed == false && input.key_up_pressed == false && player.look == 0){
          player.sprite = initialiser_image("link_idle_up.png",player.dst.x,player.dst.y,18*1.5,23*1.5,&player.src,&player.dst,pRenderer);
        }
        else if (input.key_right_pressed == false && input.key_down_pressed == false && input.key_left_pressed == false && input.key_up_pressed == false && player.look == 1){
          player.sprite = initialiser_image("link_idle_down.png",player.dst.x,player.dst.y,18*1.5,26*1.5,&player.src,&player.dst,pRenderer);
        }
        else if (input.key_right_pressed == false && input.key_down_pressed == false && input.key_left_pressed == false && input.key_up_pressed == false && player.look == 2){
          player.sprite = initialiser_image("link_idle_left.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
        }
        else if (input.key_right_pressed == false && input.key_down_pressed == false && input.key_left_pressed == false && input.key_up_pressed == false && player.look == 3){
          player.sprite = initialiser_image("link_idle_right.png",player.dst.x,player.dst.y,19*1.5,23*1.5,&player.src,&player.dst,pRenderer);
        }

        }

      for(i=0;i<19;i++){
        if (live_bullet[i] != -1){
          afficher_image(pRenderer, pTexture_bullet[i], src_bullet[i], dst_bullet[i]);
        }
      }
      afficher_image(pRenderer, player.sprite, player.src, player.dst);

			SDL_RenderPresent(pRenderer); // Met à jour la fenêtre

      SDL_Delay(5);

		}

    Mix_FreeChunk(sound_bullet);
    Mix_FreeMusic(musique);
    Mix_CloseAudio(); //Fermeture de l'API
		SDL_DestroyRenderer(pRenderer);
		SDL_DestroyWindow(pWindow);
    TTF_Quit();
    SDL_Quit(); // Arrêt de la SDL (libération de la mémoire).

    return 0;
}
