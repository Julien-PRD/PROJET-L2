#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "fonction_basiques.h"

SDL_Texture* initialiser_image(char * nom_image, int position_x, int position_y, int largeur, int hauteur, SDL_Rect *src, SDL_Rect *dst, SDL_Renderer* pRenderer){

	SDL_Surface* image = IMG_Load(nom_image); // Pointeur sur une SDL_Surface qui contient l'image
	if(!image) {															// Gestion de l'erreur si l'image ne charge pas
    	printf("IMG_Load: %s\n", IMG_GetError());
	}
	SDL_Texture* pTextureImage = SDL_CreateTextureFromSurface(pRenderer, image);	// On crée une texture depuis l'image
	SDL_FreeSurface(image);	// On libère le SDL_Surface
	src->x = src->y = src->w = src->h = 0; // x,y,largeur,hauteur de l'image de base
    dst->x = position_x;
    dst->y = position_y;
    dst->w = largeur;
    dst->h = hauteur;
	SDL_QueryTexture(pTextureImage, NULL, NULL, &src->w, &src->h);	// on prépare la texture
    return pTextureImage;

}

SDL_Texture* initialiser_image_remastered(SDL_Surface* surface, int position_x, int position_y, int largeur, int hauteur, SDL_Rect *src, SDL_Rect *dst, SDL_Renderer* pRenderer){

	SDL_Texture* pTextureImage = SDL_CreateTextureFromSurface(pRenderer, surface);	// On crée une texture depuis l'image
	src->x = src->y = src->w = src->h = 0; // x,y,largeur,hauteur de l'image de base
    dst->x = position_x;
    dst->y = position_y;
    dst->w = largeur;
    dst->h = hauteur;
	SDL_QueryTexture(pTextureImage, NULL, NULL, &src->w, &src->h);	// on prépare la texture
    return pTextureImage;

}

int chercher_indice_image(char* nom_image , load_image_t tab_load_image[NB_IMAGE]){
	int i;
	for (i = 0; i < NB_IMAGE ; i++){
		if (strcmp(tab_load_image[i].nom_image,nom_image) == 0){
			return i;
		}
	}
}

void chargement_image(load_image_t tab_load_image[NB_IMAGE]){
	
	tab_load_image[0].surface = IMG_Load("arrow_down.png");
	tab_load_image[0].nom_image = "arrow_down.png";
	tab_load_image->surface[1] = IMG_Load("arrow_up.png");
	tab_load_image->nom_image[1] = "arrow_up.png";
	tab_load_image->surface[2] = IMG_Load("arrow_left.png");
	tab_load_image->nom_image[2] = "arrow_left.png";
	tab_load_image->surface[3] = IMG_Load("arrow_right.png");
	tab_load_image->nom_image[3] = "arrow_right.png";
	tab_load_image->surface[4] = IMG_Load("link_idle_down.png");
	tab_load_image->nom_image[4] = "link_idle_down.png";
	tab_load_image->surface[5] = IMG_Load("link_idle_up.png");
	tab_load_image->nom_image[5] = "link_idle_up.png";
	tab_load_image->surface[6] = IMG_Load("link_idle_left.png");
	tab_load_image->nom_image[6] = "link_idle_left.png";
	tab_load_image->surface[7] = IMG_Load("link_idle_right.png");
	tab_load_image->nom_image[7] = "link_idle_right.png";
	tab_load_image->surface[8] = IMG_Load("link_walking_down_1.png");
	tab_load_image->nom_image[8] = "link_walking_down_1.png";
	tab_load_image->surface[9] = IMG_Load("link_walking_down_2.png");
	tab_load_image->nom_image[9] = "link_walking_down_2.png";
	tab_load_image->surface[10] = IMG_Load("link_walking_down_3.png");
	tab_load_image->nom_image[10] = "link_walking_down_3.png";
	tab_load_image->surface[11] = IMG_Load("link_walking_down_4.png");
	tab_load_image->nom_image[11] = "link_walking_down_4.png";
	tab_load_image->surface[12] = IMG_Load("link_walking_down_5.png");
	tab_load_image->nom_image[12] = "link_walking_down_5.png";
	tab_load_image->surface[13] = IMG_Load("link_walking_down_6.png");
	tab_load_image->nom_image[13] = "link_walking_down_6.png";
	tab_load_image->surface[14] = IMG_Load("link_walking_left_1.png");
	tab_load_image->nom_image[14] = "link_walking_left_1.png";
	tab_load_image->surface[15] = IMG_Load("link_walking_left_2.png");
	tab_load_image->nom_image[15] = "link_walking_left_2.png";
	tab_load_image->surface[16] = IMG_Load("link_walking_left_3.png");
	tab_load_image->nom_image[16] = "link_walking_left_3.png";
	tab_load_image->surface[17] = IMG_Load("link_walking_left_4.png");
	tab_load_image->nom_image[17] = "link_walking_left_4.png";
	tab_load_image->surface[18] = IMG_Load("link_walking_left_5.png");
	tab_load_image->nom_image[18] = "link_walking_left_5.png";
	tab_load_image->surface[19] = IMG_Load("link_walking_left_6.png");
	tab_load_image->nom_image[19] = "link_walking_left_6.png";
	tab_load_image->surface[20] = IMG_Load("link_walking_right_1.png");
	tab_load_image->nom_image[20] = "link_walking_right_1.png";
	tab_load_image->surface[21] = IMG_Load("link_walking_right_2.png");
	tab_load_image->nom_image[21] = "link_walking_right_2.png";
	tab_load_image->surface[22] = IMG_Load("link_walking_right_3.png");
	tab_load_image->nom_image[22] = "link_walking_right_3.png";
	tab_load_image->surface[23] = IMG_Load("link_walking_right_4.png");
	tab_load_image->nom_image[23] = "link_walking_right_4.png";
	tab_load_image->surface[24] = IMG_Load("link_walking_right_5.png");
	tab_load_image->nom_image[24] = "link_walking_right_5.png";
	tab_load_image->surface[25] = IMG_Load("link_walking_right_6.png");
	tab_load_image->nom_image[25] = "link_walking_right_6.png";
	tab_load_image->surface[26] = IMG_Load("link_walking_up_1.png");
	tab_load_image->nom_image[26] = "link_walking_up_1.png";
	tab_load_image->surface[27] = IMG_Load("link_walking_up_2.png");
	tab_load_image->nom_image[27] = "link_walking_up_2.png";
	tab_load_image->surface[28] = IMG_Load("link_walking_up_3.png");
	tab_load_image->nom_image[28] = "link_walking_up_3.png";
	tab_load_image->surface[29] = IMG_Load("link_walking_up_4.png");
	tab_load_image->nom_image[29] = "link_walking_up_4.png";
	tab_load_image->surface[30] = IMG_Load("link_walking_up_5.png");
	tab_load_image->nom_image[30] = "link_walking_up_5.png";
	tab_load_image->surface[31] = IMG_Load("link_walking_up_6.png");
	tab_load_image->nom_image[31] = "link_walking_up_6.png";
	tab_load_image->surface[32] = IMG_Load("link_shooting_down_1.png");
	tab_load_image->nom_image[32] = "link_shooting_down_1.png";
	tab_load_image->surface[33] = IMG_Load("link_shooting_down_2.png");
	tab_load_image->nom_image[33] = "link_shooting_down_2.png";
	tab_load_image->surface[34] = IMG_Load("link_shooting_down_3.png");
	tab_load_image->nom_image[34] = "link_shooting_down_3.png";
	tab_load_image->surface[35] = IMG_Load("link_shooting_down_4.png");
	tab_load_image->nom_image[35] = "link_shooting_down_4.png";
	tab_load_image->surface[36] = IMG_Load("link_shooting_down_5.png");
	tab_load_image->nom_image[36] = "link_shooting_down_5.png";
	tab_load_image->surface[37] = IMG_Load("link_shooting_down_6.png");
	tab_load_image->nom_image[37] = "link_shooting_down_6.png";
	tab_load_image->surface[38] = IMG_Load("link_shooting_left_1.png");
	tab_load_image->nom_image[38] = "link_shooting_left_1.png";
	tab_load_image->surface[39] = IMG_Load("link_shooting_left_2.png");
	tab_load_image->nom_image[39] = "link_shooting_left_2.png";
	tab_load_image->surface[40] = IMG_Load("link_shooting_left_3.png");
	tab_load_image->nom_image[40] = "link_shooting_left_3.png";
	tab_load_image->surface[41] = IMG_Load("link_shooting_left_4.png");
	tab_load_image->nom_image[41] = "link_shooting_left_4.png";
	tab_load_image->surface[42] = IMG_Load("link_shooting_left_5.png");
	tab_load_image->nom_image[42] = "link_shooting_left_5.png";
	tab_load_image->surface[43] = IMG_Load("link_shooting_left_6.png");
	tab_load_image->nom_image[43] = "link_shooting_left_6.png";
	tab_load_image->surface[44] = IMG_Load("link_shooting_right_1.png");
	tab_load_image->nom_image[44] = "link_shooting_right_1.png";
	tab_load_image->surface[45] = IMG_Load("link_shooting_right_2.png");
	tab_load_image->nom_image[45] = "link_shooting_right_2.png";
	tab_load_image->surface[46] = IMG_Load("link_shooting_right_3.png");
	tab_load_image->nom_image[46] = "link_shooting_right_3.png";
	tab_load_image->surface[47] = IMG_Load("link_shooting_right_4.png");
	tab_load_image->nom_image[47] = "link_shooting_right_4.png";
	tab_load_image->surface[48] = IMG_Load("link_shooting_right_5.png");
	tab_load_image->nom_image[48] = "link_shooting_right_5.png";
	tab_load_image->surface[49] = IMG_Load("link_shooting_right_6.png");
	tab_load_image->nom_image[49] = "link_shooting_right_6.png";
	tab_load_image->surface[50] = IMG_Load("link_shooting_up_1.png");
	tab_load_image->nom_image[50] = "link_shooting_up_1.png";
	tab_load_image->surface[51] = IMG_Load("link_shooting_up_2.png");
	tab_load_image->nom_image[51] = "link_shooting_up_2.png";
	tab_load_image->surface[52] = IMG_Load("link_shooting_up_3.png");
	tab_load_image->nom_image[52] = "link_shooting_up_3.png";
	tab_load_image->surface[53] = IMG_Load("link_shooting_up_4.png");
	tab_load_image->nom_image[53] = "link_shooting_up_4.png";
	tab_load_image->surface[54] = IMG_Load("link_shooting_up_5.png");
	tab_load_image->nom_image[54] = "link_shooting_up_5.png";
	tab_load_image->surface[55] = IMG_Load("link_shooting_up_6.png");
	tab_load_image->nom_image[55] = "link_shooting_up_6.png";
	tab_load_image->surface[56] = IMG_Load("inventory_final.png");
	tab_load_image->nom_image[56] = "inventory_final.png";
	tab_load_image->surface[57] = IMG_Load("map.png");
	tab_load_image->nom_image[57] = "map.png";
	tab_load_image->surface[58] = IMG_Load("map_couleur.png");
	tab_load_image->nom_image[58] = "map_couleur.png";

}

void detruire_image(load_image_t tab_load_image[NB_IMAGE]){
	int i;
	for (i = 0; i < NB_IMAGE; i++){
		SDL_FreeSurface(tab_load_image[i].surface);
	}
}

Uint32 getpixel(SDL_Surface *surface, int x, int y){
	// Fonction getpixel tirée de la SDL 1 non incluse dans la SDL 2
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to retrieve */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp) {
    case 1:
        return *p;

    case 2:
        return *(Uint16 *)p;

    case 3:
        if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
            return p[0] << 16 | p[1] << 8 | p[2];
        else
            return p[0] | p[1] << 8 | p[2] << 16;

    case 4:
        return *(Uint32 *)p;

    default:
        return 0;       /* shouldn't happen, but avoids warnings */
    }
}


player_t initialiser_joueur(player_t player, SDL_Renderer* pRenderer){
	player.bullet_shot = false;
	player.idle = true;
	player.look_down = 1;
	player.look_left = player.look_right = player.look_up = 0;
	player.changement_frame = player.animation = player.animation_shoot = player.old_animation = player.compteur_animation = player.compteur_animation_shoot = 0;
	player.limite_compteur_animation = 25;
	player.limite_compteur_animation_shoot = 15;
	player.speed = 1;
	player.look = 1;

	player.input.key_up_pressed = player.input.key_down_pressed = player.input.key_left_pressed = player.input.key_right_pressed = player.input.key_space_pressed = player.input.key_shift_pressed = false;

	for (int i = 0; i<19 ;i++){
		player.src_bullet[i].x = player.src_bullet[i].y = player.src_bullet[i].h = player.src_bullet[i].w = 0;
		player.live_bullet[i] = -1;
	}
	player.nb_bullet = 0;

	player.image.nom_image = "link_idle_down.png";
	player.image.position_x = 200;
	player.image.position_y = 480;
	player.image.largeur = 19*1.5;
	player.image.hauteur = 23*1.5;
	player.image.texture = initialiser_image(player.image.nom_image,player.image.position_x,player.image.position_y,player.image.largeur,player.image.hauteur,&player.image.src,&player.image.dst,pRenderer);

	return player;
}

void afficher_image(SDL_Renderer* pRenderer, SDL_Texture* pTextureImage, SDL_Rect src, SDL_Rect dst){
  SDL_RenderCopy(pRenderer, pTextureImage, &src, &dst);
}

int est_dedans(SDL_Rect objet, SDL_Event events){

  if (events.button.x >= objet.x && events.button.x <= objet.x+objet.w && events.button.y >= objet.y && events.button.y <= objet.y+objet.h){
    // printf("est_dedans 1 \n");
    return 1;
  }
  else {
    //printf("est_dedans 0 \n");
    return 0;
  }

}


int find_case (SDL_Rect ecran_to_find[196], SDL_Event events){
  int i;
  for(i=0;i<196;i++){
    if(est_dedans(ecran_to_find[i],events)){
      fprintf(stdout,"Trouvé ! case nb : %d de x : %d et y : %d \n", i, ecran_to_find[i].x, ecran_to_find[i].y);
      return i;
    }
  }
}

int find_screen (case_t screen_to_find[196], SDL_Event events){
  int i;
  for(i=0;i<196;i++){
    if(est_dedans(screen_to_find[i].rectangle,events)){
      fprintf(stdout,"Trouvé ! case nb : %d de x : %d et y : %d \n", i, screen_to_find[i].rectangle.x, screen_to_find[i].rectangle.y);
      return i;
    }
  }
}

player_t check_and_reset_animation (player_t player){

	if(player.input.key_space_pressed == false && player.animation_shoot !=0 || (player.animation_shoot == 0 && player.compteur_animation_shoot !=0)){
		if (player.animation_shoot <= 0 && player.compteur_animation_shoot >= 25){
			player.animation_shoot = 1;
			player.compteur_animation_shoot = 0;
		}
		else if (player.animation_shoot >= 1 && player.compteur_animation_shoot >= 25){
			player.animation_shoot = 0;
			player.compteur_animation_shoot = 0;
		}
		else {
			player.compteur_animation_shoot++;
		}
	}

	return player;
}

player_t update_arrow (player_t player){
	if (player.bullet_shot == true){
		for (int i = 0; i < 19 ; i++){
			//SDL_Log("la bullet : %d est dans l'etat player.live_bullet : %d", i, player.live_bullet[i]);
			if (player.dst_bullet[i].y <= 10 || player.dst_bullet[i].y >= 830 || player.dst_bullet[i].x <= 10 || player.dst_bullet[i].x >= 830){
				player.live_bullet[i] = -1;
			}
			else if (player.dst_bullet[i].y > -10 && player.dir_bullet[i] == 0 && player.live_bullet[i] != -1){
				player.dst_bullet[i].y -= 1;
			}
			else if (player.dst_bullet[i].y < 850 && player.dir_bullet[i] == 1 && player.live_bullet[i] != -1){
				player.dst_bullet[i].y += 1;
			}
			else if (player.dst_bullet[i].x > -10 && player.dir_bullet[i] == 2 && player.live_bullet[i] != -1){
				player.dst_bullet[i].x -= 1;
			}
			else if (player.dst_bullet[i].x < 850 && player.dir_bullet[i] == 3 && player.live_bullet[i] != -1){
				player.dst_bullet[i].x += 1;
			}
		}
		if (player.nb_bullet == 19){
			player.nb_bullet = 0;
		}
	}

	return player;
}

player_t player_moving (player_t player, SDL_Renderer* pRenderer, SDL_Surface* couleur_image){
	Uint8 r, g, b;
    Uint32 pixel;
	if (player.input.key_up_pressed == true){
		pixel = getpixel(couleur_image, player.image.dst.x+12, player.image.dst.y-4);
		SDL_GetRGB(pixel, couleur_image->format, &r, &g, &b);
		if (player.image.dst.y >= 0 && g == 255 && r == 0){
			player.image.dst.y -= player.speed;
		}
		if (player.animation == 0){
			player.image = changement_image(player.image, "link_walking_up_1.png", player.image.dst.x, player.image.dst.y, 18*1.5, 24*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 1){
			player.image = changement_image(player.image, "link_walking_up_2.png", player.image.dst.x, player.image.dst.y, 18*1.5, 27*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 2){
			player.image = changement_image(player.image, "link_walking_up_3.png", player.image.dst.x, player.image.dst.y, 18*1.5, 25*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 3){
			player.image = changement_image(player.image, "link_idle_up.png", player.image.dst.x, player.image.dst.y, 18*1.5, 23*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 4){
			player.image = changement_image(player.image, "link_walking_up_4.png", player.image.dst.x, player.image.dst.y, 18*1.5, 24*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 5){
			player.image = changement_image(player.image, "link_walking_up_5.png", player.image.dst.x, player.image.dst.y, 18*1.5, 27*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 6){
			player.image = changement_image(player.image, "link_walking_up_6.png", player.image.dst.x, player.image.dst.y, 18*1.5, 25*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation = 0;
				player.compteur_animation = 0;
			}
		}
	}
else if (player.input.key_down_pressed == true){
	pixel = getpixel(couleur_image, player.image.dst.x+12, player.image.dst.y+42);
	SDL_GetRGB(pixel, couleur_image->format, &r, &g, &b);
	if (player.image.dst.y <= 840 - 56 && g == 255 & r == 0){
		player.image.dst.y += player.speed;
	}
	if (player.animation == 0){
			player.image = changement_image(player.image, "link_walking_down_1.png", player.image.dst.x, player.image.dst.y, 18*1.5, 29*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 1){
			player.image = changement_image(player.image, "link_walking_down_2.png", player.image.dst.x, player.image.dst.y, 18*1.5, 28*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 2){
			player.image = changement_image(player.image, "link_walking_down_3.png", player.image.dst.x, player.image.dst.y, 18*1.5, 25*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 3){
			player.image = changement_image(player.image, "link_idle_down.png", player.image.dst.x, player.image.dst.y, 18*1.5, 26*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 4){
			player.image = changement_image(player.image, "link_walking_down_4.png", player.image.dst.x, player.image.dst.y, 18*1.5, 29*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 5){
			player.image = changement_image(player.image, "link_walking_down_5.png", player.image.dst.x, player.image.dst.y, 18*1.5, 28*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 6){
			player.image = changement_image(player.image, "link_walking_down_6.png", player.image.dst.x, player.image.dst.y, 18*1.5, 25*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation = 0;
				player.compteur_animation = 0;
			}
		}
}
else if (player.input.key_left_pressed == true){
	pixel = getpixel(couleur_image, player.image.dst.x-2, player.image.dst.y+15);
	SDL_GetRGB(pixel, couleur_image->format, &r, &g, &b);
	if (player.image.dst.x >= 0 && g == 255 && r == 0){
		player.image.dst.x -= player.speed;
	}
		if (player.animation == 0){
			player.image = changement_image(player.image, "link_walking_left_1.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 1){
			player.image = changement_image(player.image, "link_walking_left_2.png", player.image.dst.x, player.image.dst.y, 23*1.5, 22*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 2){
			player.image = changement_image(player.image, "link_walking_left_3.png", player.image.dst.x, player.image.dst.y, 24*1.5, 22*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 3){
			player.image = changement_image(player.image, "link_idle_left.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 4){
			player.image = changement_image(player.image, "link_walking_left_4.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 5){
			player.image = changement_image(player.image, "link_walking_left_5.png", player.image.dst.x, player.image.dst.y, 23*1.5, 22*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 6){
			player.image = changement_image(player.image, "link_walking_left_6.png", player.image.dst.x, player.image.dst.y, 24*1.5, 22*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation = 0;
				player.compteur_animation = 0;
			}
		}
}
else if (player.input.key_right_pressed == true){
	pixel = getpixel(couleur_image, player.image.dst.x+35, player.image.dst.y+15);
	SDL_GetRGB(pixel, couleur_image->format, &r, &g, &b);
	if (player.image.dst.x <= 840 - 45 && g == 255 && r == 0){
		player.image.dst.x += player.speed;
	}
		if (player.animation == 0){
			player.image = changement_image(player.image, "link_walking_right_1.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 1){
			player.image = changement_image(player.image, "link_walking_right_2.png", player.image.dst.x, player.image.dst.y, 23*1.5, 22*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 2){
			player.image = changement_image(player.image, "link_walking_right_3.png", player.image.dst.x, player.image.dst.y, 24*1.5, 22*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 3){
			player.image = changement_image(player.image, "link_idle_right.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 4){
			player.image = changement_image(player.image, "link_walking_right_4.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 5){
			player.image = changement_image(player.image, "link_walking_right_5.png", player.image.dst.x, player.image.dst.y, 23*1.5, 22*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation++;
				player.compteur_animation = 0;
			}
		}
		else if (player.animation == 6){
			player.image = changement_image(player.image, "link_walking_right_6.png", player.image.dst.x, player.image.dst.y, 24*1.5, 22*1.5, pRenderer);
			player.compteur_animation++;
			if (player.compteur_animation >= player.limite_compteur_animation){
				player.animation = 0;
				player.compteur_animation = 0;
			}
		}
}

else if (player.input.key_right_pressed == false && player.input.key_down_pressed == false && player.input.key_left_pressed == false && player.input.key_up_pressed == false && player.look == 0){
	player.image = changement_image(player.image, "link_idle_up.png", player.image.dst.x, player.image.dst.y, 18*1.5, 23*1.5, pRenderer);
}
else if (player.input.key_right_pressed == false && player.input.key_down_pressed == false && player.input.key_left_pressed == false && player.input.key_up_pressed == false && player.look == 1){
	player.image = changement_image(player.image, "link_idle_down.png", player.image.dst.x, player.image.dst.y, 18*1.5, 26*1.5, pRenderer);
}
else if (player.input.key_right_pressed == false && player.input.key_down_pressed == false && player.input.key_left_pressed == false && player.input.key_up_pressed == false && player.look == 2){
	player.image = changement_image(player.image, "link_idle_left.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
}
else if (player.input.key_right_pressed == false && player.input.key_down_pressed == false && player.input.key_left_pressed == false && player.input.key_up_pressed == false && player.look == 3){
	player.image = changement_image(player.image, "link_idle_right.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
}

	return player;

}

player_t player_shooting_bow (player_t player, Mix_Chunk *sound_bow, Mix_Chunk *sound_arrow, SDL_Renderer* pRenderer){

	if(player.input.key_space_pressed == true && player.look == 0){
		player.input.key_down_pressed = player.input.key_left_pressed = player.input.key_right_pressed = player.input.key_up_pressed = false;
		if (player.animation_shoot == 0){
			player.image = changement_image(player.image, "link_shooting_up_1.png", player.image.dst.x, player.image.dst.y, 21*1.5, 28*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 1){
			player.image = changement_image(player.image, "link_shooting_up_2.png", player.image.dst.x, player.image.dst.y, 22*1.5, 27*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 2){
			player.image = changement_image(player.image, "link_shooting_up_3.png", player.image.dst.x, player.image.dst.y, 22*1.5, 27*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 3){
			player.image = changement_image(player.image, "link_shooting_up_4.png", player.image.dst.x, player.image.dst.y, 24*1.5, 27*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 4){
			if (player.compteur_animation_shoot <= 0 && player.live_bullet[player.nb_bullet] == -1){
				player.bullet_shot = true;
				player.dir_bullet[player.nb_bullet] = 0;
				player.live_bullet[player.nb_bullet] = 1;
				player.pTexture_bullet[player.nb_bullet] = initialiser_image("arrow_up.png",player.image.dst.x+10,player.image.dst.y+13,5*1.5,15*1.5,&player.src_bullet[player.nb_bullet],&player.dst_bullet[player.nb_bullet],pRenderer);
				Mix_PlayChannel(1, sound_arrow, 0);
				player.nb_bullet++;
			}
			player.image = changement_image(player.image, "link_shooting_up_5.png", player.image.dst.x, player.image.dst.y, 21*1.5, 26*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 5){
			player.image = changement_image(player.image, "link_shooting_up_6.png", player.image.dst.x, player.image.dst.y, 21*1.5, 24*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 6){
			player.image = changement_image(player.image, "link_idle_up.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot = 0;
				player.compteur_animation_shoot = 0;
			}
		}
	}
	else if(player.input.key_space_pressed == true && player.look == 1){
		player.input.key_down_pressed = player.input.key_left_pressed = player.input.key_right_pressed = player.input.key_up_pressed = false;
		if (player.animation_shoot == 0){
			player.image = changement_image(player.image, "link_shooting_down_1.png", player.image.dst.x, player.image.dst.y, 21*1.5, 28*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 1){
			player.image = changement_image(player.image, "link_shooting_down_2.png", player.image.dst.x, player.image.dst.y, 22*1.5, 27*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 2){
			player.image = changement_image(player.image, "link_shooting_down_3.png", player.image.dst.x, player.image.dst.y, 22*1.5, 27*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 3){
			player.image = changement_image(player.image, "link_shooting_down_4.png", player.image.dst.x, player.image.dst.y, 24*1.5, 27*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 4){
			if (player.compteur_animation_shoot <= 0 && player.live_bullet[player.nb_bullet] == -1){
				player.bullet_shot = true;
				player.dir_bullet[player.nb_bullet] = 1;
				player.live_bullet[player.nb_bullet] = 1;
				player.pTexture_bullet[player.nb_bullet] = initialiser_image("arrow_down.png",player.image.dst.x+16,player.image.dst.y+13,5*1.5,15*1.5,&player.src_bullet[player.nb_bullet],&player.dst_bullet[player.nb_bullet],pRenderer);
				Mix_PlayChannel(1, sound_arrow, 0);
				player.nb_bullet++;
			}
			player.image = changement_image(player.image, "link_shooting_down_5.png", player.image.dst.x, player.image.dst.y, 21*1.5, 26*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 5){
			player.image = changement_image(player.image, "link_shooting_down_6.png", player.image.dst.x, player.image.dst.y, 21*1.5, 24*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 6){
			player.image = changement_image(player.image, "link_idle_down.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot = 0;
				player.compteur_animation_shoot = 0;
			}
		}
	}
	else if (player.input.key_space_pressed == true && player.look == 2){
		player.input.key_down_pressed = player.input.key_left_pressed = player.input.key_right_pressed = player.input.key_up_pressed = false;
		if (player.animation_shoot == 0){
			player.image = changement_image(player.image, "link_shooting_left_1.png", player.image.dst.x, player.image.dst.y, 24*1.5, 25*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 1){
			player.image = changement_image(player.image, "link_shooting_left_2.png", player.image.dst.x, player.image.dst.y, 27*1.5, 25*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 2){
			player.image = changement_image(player.image, "link_shooting_left_3.png", player.image.dst.x, player.image.dst.y, 24*1.5, 25*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 3){
			player.image = changement_image(player.image, "link_shooting_left_4.png", player.image.dst.x, player.image.dst.y, 28*1.5, 24*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 4){
			if (player.compteur_animation_shoot <= 0 && player.live_bullet[player.nb_bullet] == -1){
				player.bullet_shot = true;
				player.dir_bullet[player.nb_bullet] = 2;
				player.live_bullet[player.nb_bullet] = 1;
				player.pTexture_bullet[player.nb_bullet] = initialiser_image("arrow_left.png",player.image.dst.x-10,player.image.dst.y+19,15*1.5,5*1.5,&player.src_bullet[player.nb_bullet],&player.dst_bullet[player.nb_bullet],pRenderer);
				Mix_PlayChannel(1, sound_arrow, 0);
				player.nb_bullet++;
			}
			player.image = changement_image(player.image, "link_shooting_left_5.png", player.image.dst.x, player.image.dst.y, 23*1.5, 25*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 5){
			player.image = changement_image(player.image, "link_shooting_left_6.png", player.image.dst.x, player.image.dst.y, 21*1.5, 25*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 6){
			player.image = changement_image(player.image, "link_idle_left.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot = 0;
				player.compteur_animation_shoot = 0;
			}
		}
	}
	else if(player.input.key_space_pressed == true && player.look == 3){
		player.input.key_down_pressed = player.input.key_left_pressed = player.input.key_right_pressed = player.input.key_up_pressed = false;
		if (player.animation_shoot == 0){
			player.image = changement_image(player.image, "link_shooting_right_1.png", player.image.dst.x, player.image.dst.y, 24*1.5, 25*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 1){
			player.image = changement_image(player.image, "link_shooting_right_2.png", player.image.dst.x, player.image.dst.y, 27*1.5, 25*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 2){
			player.image = changement_image(player.image, "link_shooting_right_3.png", player.image.dst.x, player.image.dst.y, 24*1.5, 25*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 3){
			player.image = changement_image(player.image, "link_shooting_right_4.png", player.image.dst.x, player.image.dst.y, 28*1.5, 24*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				Mix_PlayChannel(3, sound_bow, 0);
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 4){
			if (player.compteur_animation_shoot <= 0 && player.live_bullet[player.nb_bullet] == -1){
				player.bullet_shot = true;
				player.dir_bullet[player.nb_bullet] = 3;
				player.live_bullet[player.nb_bullet] = 1;
				player.pTexture_bullet[player.nb_bullet] = initialiser_image("arrow_right.png",player.image.dst.x+10,player.image.dst.y+19,15*1.5,5*1.5,&player.src_bullet[player.nb_bullet],&player.dst_bullet[player.nb_bullet],pRenderer);
				Mix_PlayChannel(1, sound_arrow, 0);
				player.nb_bullet++;
			}
			player.image = changement_image(player.image, "link_shooting_right_5.png", player.image.dst.x, player.image.dst.y, 23*1.5, 25*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 5){
			player.image = changement_image(player.image, "link_shooting_right_6.png", player.image.dst.x, player.image.dst.y, 21*1.5, 25*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot++;
				player.compteur_animation_shoot = 0;
			}
		}
		else if (player.animation_shoot == 6){
			player.image = changement_image(player.image, "link_idle_right.png", player.image.dst.x, player.image.dst.y, 19*1.5, 23*1.5, pRenderer);
			player.compteur_animation_shoot++;
			if (player.compteur_animation_shoot >= player.limite_compteur_animation_shoot){
				player.animation_shoot = 0;
				player.compteur_animation_shoot = 0;
			}
		}
	}

	return player;

}

image_t changement_image (image_t image, char * nouveau_nom_image, int nouvelle_position_x, int nouvelle_position_y, int nouvelle_largeur, int nouvelle_hauteur, SDL_Renderer* pRenderer, load_image_t tab_load_image[NB_IMAGE]){

	strcpy(image.nom_image,nouveau_nom_image);
	image.position_x = nouvelle_position_x;
	image.position_y = nouvelle_position_y;
	image.largeur = nouvelle_largeur;
	image.hauteur = nouvelle_hauteur;
	image.texture = initialiser_image_remastered(tab_load_image[chercher_indice_image(image.nom_image, tab_load_image)].surface,image.position_x,image.position_y,image.largeur,image.hauteur,&image.src,&image.dst,pRenderer);

	return image;
}