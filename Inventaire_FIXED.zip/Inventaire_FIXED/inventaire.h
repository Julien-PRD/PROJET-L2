typedef struct objet_s{
  char * nom_objet;
  char * description;
  image_t image;
  int id;
}objet_t;

typedef struct inventaire_s{
    bool is_empty;
    SDL_Rect rectangle;
    SDL_Rect dst;
    SDL_Rect src;
    objet_t objet;
}inventaire_t;

typedef struct liste_s{
  objet_t tab[8];
  int est_ramasser[8];
  int emplacement[8];
}liste_t;


void initialiser_inventaire (inventaire_t caseinv[21]);

image_t detruire_image2(image_t image);

int est_a_cote(image_t image, player_t player);

liste_t initialiser_liste (liste_t l);

liste_t remplir_inventaire(liste_t l, inventaire_t caseinv[21]);

void afficher_inventaire(inventaire_t caseinv[21], SDL_Renderer* pRenderer, load_image_t tab_load_image[NB_IMAGE]);
