#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "fonction_basiques.h"
#include "inventaire.h"
#include <time.h>

int main(int argc, char *argv[])
{
		if (SDL_Init(SDL_INIT_VIDEO) < 0){	// Initialisation de la SDL
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (SDL_Init(SDL_INIT_EVENTS) < 0){ // Initialisation des événements
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        return EXIT_FAILURE;
    }
		if (TTF_Init() < 0){ // Initialisation de SDL_ttf
    	SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", TTF_GetError());
    	return EXIT_FAILURE;
		}
    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1){ //Initialisation de l'API Mixer
      printf("%s", Mix_GetError());
    }

    SDL_Window* pWindow;
		SDL_Renderer* pRenderer;
		SDL_Event events;
    SDL_Rect positionZozor; // Position de la souris

		if (SDL_CreateWindowAndRenderer(840, 840, SDL_WINDOW_SHOWN, &pWindow, &pRenderer) < 0)	// SDL_CreateWindowAndRenderer(taille_x, taille_x, window_settings, ptr_SDL_Window, ptr_SDL_Renderer)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        SDL_Quit();
        return EXIT_FAILURE;
    }

		const char* title;

		SDL_SetWindowTitle(pWindow, "SDL_Program");	// Nom de la fenêtre
		SDL_SetRenderDrawBlendMode(pRenderer, SDL_BLENDMODE_BLEND);

    load_image_t tab_load_image[NB_IMAGE];

    chargement_image(tab_load_image);

    player_t player = initialiser_joueur(player, pRenderer, tab_load_image);

		bool isOpen = true;
    int i;

		bool inventaire_open = false;
		image_t inventaire;
		inventaire = changement_image(inventaire, "inventory_final.png", 0, 0, 840, 840, pRenderer, tab_load_image);

		srand(time(NULL));




liste_t l;
l = initialiser_liste(l);


l.tab[0].image = changement_image(l.tab[0].image, "link_idle_right.png", 200, 300, 40, 40, pRenderer, tab_load_image);
l.emplacement[0] = 1;
l.tab[1].image = changement_image(l.tab[1].image, "link_idle_left.png", 400, 300, 40, 40, pRenderer, tab_load_image);
l.emplacement[1] = 1;
l.tab[2].image = changement_image(l.tab[2].image, "link_shooting_right_5.png", 600, 300, 40, 40, pRenderer, tab_load_image);
l.emplacement[2] = 1;
l.tab[3].image = changement_image(l.tab[3].image, "link_walking_left_4.png", 800, 300, 40, 40, pRenderer, tab_load_image);
l.emplacement[3] = 1;
l.tab[4].image = changement_image(l.tab[4].image, "link_walking_right_4.png", 300, 350, 40, 40, pRenderer, tab_load_image);
l.emplacement[4] = 1;
l.tab[5].image = changement_image(l.tab[5].image, "link_walking_up_4.png", 500, 350, 40, 40, pRenderer, tab_load_image);
l.emplacement[5] = 1;
l.tab[6].image = changement_image(l.tab[6].image, "link_walking_down_4.png", 700, 350, 40, 40, pRenderer, tab_load_image);
l.emplacement[6] = 1;
/*l.tab[7].image = changement_image(l.tab[7].image, "arrow_up.png", 900, 350, 40, 40, pRenderer, tab_load_image);
l.emplacement[7] = 1;*/



		inventaire_t caseinv[21];
		initialiser_inventaire(caseinv);

bool souris = false;


    SDL_Texture* map;


    SDL_Rect rect_map, src_map, dst_map;
    map = initialiser_image_remastered(tab_load_image[57].surface,0,0,840,840,&src_map,&dst_map,pRenderer);

    SDL_Surface* couleur_image = IMG_Load("map_couleur.png");

    Mix_AllocateChannels(10);
    Mix_Volume(1,MIX_MAX_VOLUME/2);
    Mix_Chunk *sound_bullet;
		Mix_Chunk *sound_bow;
		Mix_Chunk *sound_arrow;
   // Mix_Music *musique;
    //musique = Mix_LoadMUS("zelda_theme.wav");
    //Mix_VolumeMusic(MIX_MAX_VOLUME / 4);
    sound_bullet = Mix_LoadWAV("dspistol.wav");
		sound_bow = Mix_LoadWAV("bow_pull_sound.wav");
		sound_arrow = Mix_LoadWAV("arrow_sound.wav");
		Mix_Volume(3, MIX_MAX_VOLUME/4);

    SDL_SetRenderDrawColor(pRenderer, 255, 255, 255, 255);

    //Mix_PlayMusic(musique, -1);

		while(isOpen){	// Tant que l'application est active

			while(SDL_PollEvent(&events)){	// Boucle de gestion des événements de la SDL

				switch(events.type){	// Détection des événements de la SDL

					case SDL_WINDOWEVENT: // Fermes l'application si clique de la souris sur la croix rouge de la fenêtre
							 if (events.window.event == SDL_WINDOWEVENT_CLOSE){
								 isOpen = SDL_FALSE;
								 break;
							 }

          case SDL_MOUSEMOTION:
            positionZozor.x = events.motion.x;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            positionZozor.y = events.motion.y;    /*RÉCUPÉRATION  DES COORDONNÉES DE CHAQUE ÉVÈNEMENT GÉNÉRÉ*/
            break;

          case SDL_KEYDOWN:
            if (events.key.keysym.sym == SDLK_z){
              player.input.key_up_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_s){
              player.input.key_down_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_q){
              player.input.key_left_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_d){
              player.input.key_right_pressed = true;
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              player.input.key_space_pressed = true;
            }
						if (events.key.keysym.sym == SDLK_LSHIFT){
              player.input.key_shift_pressed = true;
            }
            break;

          case SDL_KEYUP:
            if (events.key.keysym.sym == SDLK_z){
              player.input.key_up_pressed = false;
              player.look = 0;
              player.look_up = 1;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_s){
              player.input.key_down_pressed = false;
              player.look = 1;
              player.look_up = 0;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_q){
              player.input.key_left_pressed = false;
              player.look = 2;
              player.look_left = 1;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_d){
              player.input.key_right_pressed = false;
              player.look = 3;
              player.look_left = 0;
              player.animation = 0;
            }
            if (events.key.keysym.sym == SDLK_SPACE){
              player.input.key_space_pressed = false;
            }
						if (events.key.keysym.sym == SDLK_LSHIFT){
              player.input.key_shift_pressed = false;
            }


						if(events.key.keysym.sym == SDLK_i){
							if (inventaire_open == true){
								inventaire_open = false;
							}
							else{
								inventaire_open = true;
							}
						}
						for(int i=0; i<8; i++){
							if(events.key.keysym.sym == SDLK_e && player.input.key_right_pressed == false && player.input.key_down_pressed == false && player.input.key_left_pressed == false && player.input.key_up_pressed == false && est_a_cote(l.tab[i].image,player) == 1 && l.emplacement[i] == 1 && l.est_ramasser[i] == 0){
                l.est_ramasser[i] = 1;
              }
						}
            break;
				  }

			}

      SDL_RenderClear(pRenderer);	// Rempli la fenêtre

      afficher_image(pRenderer, map, src_map, dst_map);


      for(int i=0; i<8; i++){
        afficher_image(pRenderer, l.tab[i].image.texture, l.tab[i].image.src, l.tab[i].image.dst);
      }




      	player = update_arrow(player);
				player = check_and_reset_animation(player);
				if (player.input.key_space_pressed == true) {
					player = player_shooting_bow(player, sound_bow, sound_arrow, pRenderer, tab_load_image);
				}
				else{
					if (player.input.key_shift_pressed == true){
						player.speed = 2;
						player.limite_compteur_animation = 20;
					}
					else{
						player.speed = 1;
						player.limite_compteur_animation = 25;
					}
					player = player_moving(player, pRenderer, couleur_image, tab_load_image);
				}

      for(i=0;i<19;i++){
        if (player.live_bullet[i] != -1){
          afficher_image(pRenderer, player.pTexture_bullet[i], player.src_bullet[i], player.dst_bullet[i]);
        }
      }

      afficher_image(pRenderer, player.image.texture, player.image.src, player.image.dst);




			l = remplir_inventaire(l, caseinv);

			if(inventaire_open == true){
				afficher_image(pRenderer, inventaire.texture, inventaire.src, inventaire.dst);
				afficher_inventaire(caseinv, pRenderer, tab_load_image);
			}




			SDL_RenderPresent(pRenderer); // Met à jour la fenêtre

      SDL_Delay(5);

		}






    detruire_image(tab_load_image);
    SDL_FreeSurface(couleur_image);
    Mix_FreeChunk(sound_bullet);
		Mix_FreeChunk(sound_arrow);
		Mix_FreeChunk(sound_bow);
   // Mix_FreeMusic(musique);
    Mix_CloseAudio(); //Fermeture de l'API
		SDL_DestroyRenderer(pRenderer);
		SDL_DestroyWindow(pWindow);
    TTF_Quit();
    SDL_Quit(); // Arrêt de la SDL (libération de la mémoire).

    return 0;
}
